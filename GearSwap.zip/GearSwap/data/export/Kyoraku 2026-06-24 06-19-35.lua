sets.exported = {
    main="Aettir",
    sub="Utu Grip",
    head="Prestige Crown",
    body="Prestige Plate.",
    hands="Prestige Gaunt.",
    legs="Prestige Brais",
    feet="Prestige Sab.",
}