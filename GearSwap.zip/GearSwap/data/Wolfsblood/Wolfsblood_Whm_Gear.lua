-- Setup vars that are user-dependent.  Can override this in a sidecar file.
function user_setup()
    state.OffenseMode:options('Normal','Acc')
    state.CastingMode:options('Normal','Resistant')
    state.IdleMode:options('Normal','PDT','TPEat')
	state.PhysicalDefenseMode:options('PDT')
	state.MagicalDefenseMode:options('MDT')
	state.ResistDefenseMode:options('MEVA')
	state.Weapons:options('None','DualWeapons','MeleeWeapons')

	gear.obi_cure_waist = "Austerity Belt +1"
	gear.obi_cure_back = "Alaunus's Cape"

	gear.obi_nuke_waist = "Sekhmet Corset"
	gear.obi_high_nuke_waist = "Yamabuki-no-Obi"
	gear.obi_nuke_back = "Toro Cape"

		-- Additional local binds
	send_command('bind ^` input /ma "Arise" <t>')
	send_command('bind !` input /ja "Penury" <me>')
	send_command('bind @` gs c cycle MagicBurstMode')
	send_command('bind ^@!` gs c toggle AutoCaress')
	send_command('bind ^backspace input /ja "Sacrosanctity" <me>')
	send_command('bind @backspace input /ma "Aurora Storm" <me>')
	send_command('bind !pause gs c toggle AutoSubMode') --Automatically uses sublimation.
	send_command('bind !backspace input /ja "Accession" <me>')
	send_command('bind != input /ja "Sublimation" <me>')
	send_command('bind ^delete input /ja "Dark Arts" <me>')
	send_command('bind !delete input /ja "Addendum: Black" <me>')
	send_command('bind @delete input /ja "Manifestation" <me>')
	send_command('bind ^\\\\ input /ma "Protectra V" <me>')
	send_command('bind @\\\\ input /ma "Shellra V" <me>')
	send_command('bind !\\\\ input /ma "Reraise IV" <me>')

    select_default_macro_book()
end

-- Define sets and vars used by this job file.4
function init_gear_sets()
    --------------------------------------
    -- Start defining the sets
    --------------------------------------

	-- Weapons sets
	sets.weapons.MeleeWeapons = {main={ name="Queller Rod", augments={'Healing magic skill +15','"Cure" potency +10%','"Cure" spellcasting time -7%',}},
    sub="Sors Shield",}
	sets.weapons.DualWeapons = {main="Yagrush",sub="Nehushtan"}
	
    -- Precast Sets

    -- Fast cast sets for spells
    sets.precast.FC = { ammo="Incantor Stone",
    head="Nahtirah Hat",
    body="Ayanmo Corazza +2",
    hands="Aya. Manopolas +2",
    legs="Aya. Cosciales +2",
    feet="Regal Pumps +1",
    neck={ name="Cleric's Torque", augments={'Path: A',}},
    waist="Witful Belt",
    left_ear="Mendi. Earring",
    right_ear="Nourish. Earring +1",
    left_ring="Ayanmo Ring",
    right_ring="Veneficium Ring",
    back={ name="Alaunus's Cape", augments={'MND+20','Eva.+20 /Mag. Eva.+20','MND+10','"Fast Cast"+10','Occ. inc. resist. to stat. ailments+10',}},}
		
    sets.precast.FC.DT = { ammo="Incantor Stone",
    head="Nahtirah Hat",
    body="Ayanmo Corazza +2",
    hands="Aya. Manopolas +2",
    legs="Aya. Cosciales +2",
    feet="Regal Pumps +1",
    neck={ name="Cleric's Torque", augments={'Path: A',}},
    waist="Witful Belt",
    left_ear="Mendi. Earring",
    right_ear="Nourish. Earring +1",
    left_ring="Ayanmo Ring",
    right_ring="Sirona's Ring",
    back={ name="Alaunus's Cape", augments={'MND+20','Eva.+20 /Mag. Eva.+20','MND+10','"Fast Cast"+10','Occ. inc. resist. to stat. ailments+10',}},}

    sets.precast.FC['Enhancing Magic'] = set_combine(sets.precast.FC, {waist="Siegel Sash"})
	
    sets.precast.FC.Stoneskin = set_combine(sets.precast.FC['Enhancing Magic'], {})

    sets.precast.FC['Healing Magic'] = set_combine(sets.precast.FC, {legs="Vanya Clogs"})

    sets.precast.FC.StatusRemoval = {main="Yagrush"}
	
    sets.precast.FC.Cure = set_combine(sets.precast.FC['Healing Magic'], {feet={ name="Vanya Clogs", augments={'"Cure" potency +5%','"Cure" spellcasting time -15%','"Conserve MP"+6',}},})
	
	sets.precast.FC.Cure.DT = {main=gear.grioavolr_fc_staff,sub="Clerisy Strap +1",ammo="Impatiens",
		head="Nahtirah Hat",neck="Cleric's torque",ear1="Enchntr. Earring +1",ear2="Genmei Earring",
		body="Inyanga Jubbah +2",hands="Inyan. Dastanas +2",ring1="Defending Ring",ring2="Lebeche Ring",
		back="Perimede Cape",waist="Witful Belt",legs="Ebers Pant. +1",feet="Hygieia Clogs +1"}

    sets.precast.FC.Curaga = sets.precast.FC.Cure

	sets.precast.FC.CureSolace = sets.precast.FC.Cure

	sets.precast.FC.Impact =  set_combine(sets.precast.FC, {head=empty,body="Twilight Cloak"})

    -- Precast sets to enhance JAs
    sets.precast.JA.Benediction = {body="Piety Briault +3"}

    -- Waltz set (chr and vit)
    sets.precast.Waltz = {
		head="Nahtirah Hat",ear1="Roundel Earring",
		body="Ebers Bliaud +1",hands="Telchine Gloves",
		waist="Chaac Belt",back="Aurist's Cape +1"}

    -- Weaponskill sets

    -- Default set for any weaponskill that isn't any more specifically defined
    sets.precast.WS = {ammo="Incantor Stone",
    head="Aya. Zucchetto +2",
    body="Ayanmo Corazza +2",
    hands="Aya. Manopolas +2",
    legs="Aya. Cosciales +2",
    feet="Aya. Gambieras +2",
    neck={ name="Cleric's Torque", augments={'Path: A',}},
    waist="Witful Belt",
    left_ear="Mendi. Earring",
    right_ear="Nourish. Earring +1",
    left_ring="Ayanmo Ring",
    right_ring="Sirona's Ring",
    back={ name="Alaunus's Cape", augments={'MND+20','Eva.+20 /Mag. Eva.+20','MND+10','"Fast Cast"+10','Occ. inc. resist. to stat. ailments+10',}},}
		
    sets.precast.WS.Dagan = {ammo="Hasty Pinion +1",
		head="Inyanga Tiara +2",neck="Asperity Necklace",ear1="Genmei Earring",ear2="Moonshade Earring",
		body="Kaykaus Bliaut",hands="Telchine Gloves",ring1="Stikini Ring",ring2="Stikini Ring +1",
		back="Buquwik Cape",waist="Fotia Belt",legs="Assid. Pants +1",feet="Gende. Galosh. +1"}
		
	sets.MaxTP = {ear1="Cessance Earring",ear2="Brutal Earring"}
	sets.MaxTP.Dagan = {ear1="Genmei Earring",ear2="Evans Earring"}

    --sets.precast.WS['Flash Nova'] = {}

    --sets.precast.WS['Mystic Boon'] = {}

    -- Midcast Sets

    sets.Kiting = {feet="Herald's Gaiters"}
    sets.latent_refresh = {waist="Fucho-no-obi"}
	sets.DayIdle = {}
	sets.NightIdle = {back="Umbra Cape"}
	sets.TreasureHunter = set_combine(sets.TreasureHunter, {feet=gear.chironic_treasure_feet})
	
	--Situational sets: Gear that is equipped on certain targets
	sets.Self_Healing = {neck="Cleric's torque",ring1="Lebeche Ring",ring2="Stikini Ring +1",waist="Hachirin-no-Obi"}
	sets.Cure_Received = {neck="Phalaina Locket",ring1="Kunaji Ring",ring2="Asklepian Ring",waist="Gishdubar Sash"}
	sets.Self_Refresh = {back="Grapevine Cape",waist="Gishdubar Sash",feet="Inspirited Boots"}

	-- Conserve Mp set for spells that don't need anything else, for set_combine.
	
	sets.ConserveMP = {main=gear.grioavolr_fc_staff,sub="Umbra Strap",ammo="Hasty Pinion +1",
		head="Kaykaus Mitra +1",neck="Incanter's Torque",ear1="Gifted Earring",ear2="Gwati Earring",
		body="Vedic Coat",hands="Fanatic Gloves",ring1="Kishar Ring",ring2="Prolix Ring",
		back="Solemnity Cape",waist="Austerity Belt +1",legs="Vanya Slops",feet="Medium's Sabots"}
		
	sets.midcast.Teleport = sets.ConserveMP
	
	-- Gear for Magic Burst mode.
    sets.MagicBurst = {neck="Mizu. Kubikazari",ring1="Mujin Band",ring2="Locus Ring"}
	
    sets.midcast.FastRecast = {main=gear.grioavolr_fc_staff,sub="Clerisy Strap +1",ammo="Incantor Stone",
    head="Nahtirah Hat",
    body="Ayanmo Corazza +2",
    hands="Aya. Manopolas +2",
    legs="Aya. Cosciales +2",
    feet="Regal Pumps +1",
    neck={ name="Cleric's Torque", augments={'Path: A',}},
    waist="Witful Belt",
    left_ear="Mendi. Earring",
    right_ear="Nourish. Earring +1",
    left_ring="Ayanmo Ring",
    right_ring="Sirona's Ring",
    back={ name="Alaunus's Cape", augments={'MND+20','Eva.+20 /Mag. Eva.+20','MND+10','"Fast Cast"+10','Occ. inc. resist. to stat. ailments+10',}},}
		
    -- Cure sets

	sets.midcast['Full Cure'] = sets.midcast.FastRecast
	
	sets.midcast.Cure = {main={ name="Queller Rod", augments={'Healing magic skill +15','"Cure" potency +10%','"Cure" spellcasting time -7%',}},
	ammo="Incantor Stone",
    head={ name="Vanya Hood", augments={'MP+50','"Cure" potency +7%','Enmity-6',}},
    body="Vanya Robe",
    hands="Theophany Mitts +2",
    legs="Ebers Pantaloons",
    feet={ name="Vanya Clogs", augments={'"Cure" potency +5%','"Cure" spellcasting time -15%','"Conserve MP"+6',}},
    neck={ name="Cleric's Torque", augments={'Path: A',}},
    waist="Witful Belt",
    left_ear="Mendi. Earring",
    right_ear="Nourish. Earring +1",
    left_ring="Ayanmo Ring",
    right_ring="Sirona's Ring",
    back={ name="Alaunus's Cape", augments={'MND+20','Eva.+20 /Mag. Eva.+20','MND+10','"Fast Cast"+10','Occ. inc. resist. to stat. ailments+10',}},}
		
	sets.midcast.CureSolace = {main={ name="Queller Rod", augments={'Healing magic skill +15','"Cure" potency +10%','"Cure" spellcasting time -7%',}},
	ammo="Incantor Stone",
    head={ name="Vanya Hood", augments={'MP+50','"Cure" potency +7%','Enmity-6',}},
    body="Ebers Bliaud",
    hands="Theophany Mitts +2",
    legs="Ebers Pantaloons",
    feet={ name="Vanya Clogs", augments={'"Cure" potency +5%','"Cure" spellcasting time -15%','"Conserve MP"+6',}},
    neck={ name="Cleric's Torque", augments={'Path: A',}},
    waist="Witful Belt",
    left_ear="Mendi. Earring",
    right_ear="Nourish. Earring +1",
    left_ring="Ayanmo Ring",
    right_ring="Sirona's Ring",
    back={ name="Alaunus's Cape", augments={'MND+20','Eva.+20 /Mag. Eva.+20','MND+10','"Fast Cast"+10','Occ. inc. resist. to stat. ailments+10',}},}

	sets.midcast.LightWeatherCure = {main={ name="Queller Rod", augments={'Healing magic skill +15','"Cure" potency +10%','"Cure" spellcasting time -7%',}},
	ammo="Incantor Stone",
    head={ name="Vanya Hood", augments={'MP+50','"Cure" potency +7%','Enmity-6',}},
    body="Vanya Robe",
    hands="Theophany Mitts +2",
    legs="Ebers Pantaloons",
    feet={ name="Vanya Clogs", augments={'"Cure" potency +5%','"Cure" spellcasting time -15%','"Conserve MP"+6',}},
    neck={ name="Cleric's Torque", augments={'Path: A',}},
    waist="Witful Belt",
    left_ear="Mendi. Earring",
    right_ear="Nourish. Earring +1",
    left_ring="Ayanmo Ring",
    right_ring="Sirona's Ring",
    back={ name="Alaunus's Cape", augments={'MND+20','Eva.+20 /Mag. Eva.+20','MND+10','"Fast Cast"+10','Occ. inc. resist. to stat. ailments+10',}},}

	sets.midcast.LightWeatherCureSolace = {main={ name="Queller Rod", augments={'Healing magic skill +15','"Cure" potency +10%','"Cure" spellcasting time -7%',}},
	ammo="Incantor Stone",
    head={ name="Vanya Hood", augments={'MP+50','"Cure" potency +7%','Enmity-6',}},
    body="Vanya Robe",
    hands="Theophany Mitts +2",
    legs="Ebers Pantaloons",
    feet={ name="Vanya Clogs", augments={'"Cure" potency +5%','"Cure" spellcasting time -15%','"Conserve MP"+6',}},
    neck={ name="Cleric's Torque", augments={'Path: A',}},
    waist="Witful Belt",
    left_ear="Mendi. Earring",
    right_ear="Nourish. Earring +1",
    left_ring="Ayanmo Ring",
    right_ring="Sirona's Ring",
    back={ name="Alaunus's Cape", augments={'MND+20','Eva.+20 /Mag. Eva.+20','MND+10','"Fast Cast"+10','Occ. inc. resist. to stat. ailments+10',}},}
		
	sets.midcast.LightDayCureSolace = {main={ name="Queller Rod", augments={'Healing magic skill +15','"Cure" potency +10%','"Cure" spellcasting time -7%',}},
	ammo="Incantor Stone",
    head={ name="Vanya Hood", augments={'MP+50','"Cure" potency +7%','Enmity-6',}},
    body="Vanya Robe",
    hands="Theophany Mitts +2",
    legs="Ebers Pantaloons",
    feet={ name="Vanya Clogs", augments={'"Cure" potency +5%','"Cure" spellcasting time -15%','"Conserve MP"+6',}},
    neck={ name="Cleric's Torque", augments={'Path: A',}},
    waist="Witful Belt",
    left_ear="Mendi. Earring",
    right_ear="Nourish. Earring +1",
    left_ring="Ayanmo Ring",
    right_ring="Sirona's Ring",
    back={ name="Alaunus's Cape", augments={'MND+20','Eva.+20 /Mag. Eva.+20','MND+10','"Fast Cast"+10','Occ. inc. resist. to stat. ailments+10',}},}

	sets.midcast.LightDayCure = {main={ name="Queller Rod", augments={'Healing magic skill +15','"Cure" potency +10%','"Cure" spellcasting time -7%',}},
	ammo="Incantor Stone",
    head={ name="Vanya Hood", augments={'MP+50','"Cure" potency +7%','Enmity-6',}},
    body="Vanya Robe",
    hands="Theophany Mitts +2",
    legs="Ebers Pantaloons",
    feet={ name="Vanya Clogs", augments={'"Cure" potency +5%','"Cure" spellcasting time -15%','"Conserve MP"+6',}},
    neck={ name="Cleric's Torque", augments={'Path: A',}},
    waist="Witful Belt",
    left_ear="Mendi. Earring",
    right_ear="Nourish. Earring +1",
    left_ring="Ayanmo Ring",
    right_ring="Sirona's Ring",
    back={ name="Alaunus's Cape", augments={'MND+20','Eva.+20 /Mag. Eva.+20','MND+10','"Fast Cast"+10','Occ. inc. resist. to stat. ailments+10',}},}

	sets.midcast.Curaga = {main={ name="Queller Rod", augments={'Healing magic skill +15','"Cure" potency +10%','"Cure" spellcasting time -7%',}},
	ammo="Incantor Stone",
    head={ name="Vanya Hood", augments={'MP+50','"Cure" potency +7%','Enmity-6',}},
    body="Vanya Robe",
    hands="Theophany Mitts +2",
    legs="Ebers Pantaloons",
    feet={ name="Vanya Clogs", augments={'"Cure" potency +5%','"Cure" spellcasting time -15%','"Conserve MP"+6',}},
    neck={ name="Cleric's Torque", augments={'Path: A',}},
    waist="Witful Belt",
    left_ear="Mendi. Earring",
    right_ear="Nourish. Earring +1",
    left_ring="Ayanmo Ring",
    right_ring="Sirona's Ring",
    back={ name="Alaunus's Cape", augments={'MND+20','Eva.+20 /Mag. Eva.+20','MND+10','"Fast Cast"+10','Occ. inc. resist. to stat. ailments+10',}},}
		
	sets.midcast.LightWeatherCuraga = {main={ name="Queller Rod", augments={'Healing magic skill +15','"Cure" potency +10%','"Cure" spellcasting time -7%',}},
	ammo="Incantor Stone",
    head={ name="Vanya Hood", augments={'MP+50','"Cure" potency +7%','Enmity-6',}},
    body="Vanya Robe",
    hands="Theophany Mitts +2",
    legs="Ebers Pantaloons",
    feet={ name="Vanya Clogs", augments={'"Cure" potency +5%','"Cure" spellcasting time -15%','"Conserve MP"+6',}},
    neck={ name="Cleric's Torque", augments={'Path: A',}},
    waist="Witful Belt",
    left_ear="Mendi. Earring",
    right_ear="Nourish. Earring +1",
    left_ring="Ayanmo Ring",
    right_ring="Sirona's Ring",
    back={ name="Alaunus's Cape", augments={'MND+20','Eva.+20 /Mag. Eva.+20','MND+10','"Fast Cast"+10','Occ. inc. resist. to stat. ailments+10',}},}
		
	sets.midcast.LightDayCuraga = {main={ name="Queller Rod", augments={'Healing magic skill +15','"Cure" potency +10%','"Cure" spellcasting time -7%',}},
	ammo="Incantor Stone",
    head={ name="Vanya Hood", augments={'MP+50','"Cure" potency +7%','Enmity-6',}},
    body="Vanya Robe",
    hands="Theophany Mitts +2",
    legs="Ebers Pantaloons",
    feet={ name="Vanya Clogs", augments={'"Cure" potency +5%','"Cure" spellcasting time -15%','"Conserve MP"+6',}},
    neck={ name="Cleric's Torque", augments={'Path: A',}},
    waist="Witful Belt",
    left_ear="Mendi. Earring",
    right_ear="Nourish. Earring +1",
    left_ring="Ayanmo Ring",
    right_ring="Sirona's Ring",
    back={ name="Alaunus's Cape", augments={'MND+20','Eva.+20 /Mag. Eva.+20','MND+10','"Fast Cast"+10','Occ. inc. resist. to stat. ailments+10',}},}

	sets.midcast.Cure.DT = {main={ name="Queller Rod", augments={'Healing magic skill +15','"Cure" potency +10%','"Cure" spellcasting time -7%',}},
	ammo="Incantor Stone",
    head={ name="Vanya Hood", augments={'MP+50','"Cure" potency +7%','Enmity-6',}},
    body="Vanya Robe",
    hands="Theophany Mitts +2",
    legs="Ebers Pantaloons",
    feet={ name="Vanya Clogs", augments={'"Cure" potency +5%','"Cure" spellcasting time -15%','"Conserve MP"+6',}},
    neck={ name="Cleric's Torque", augments={'Path: A',}},
    waist="Witful Belt",
    left_ear="Mendi. Earring",
    right_ear="Nourish. Earring +1",
    left_ring="Ayanmo Ring",
    right_ring="Sirona's Ring",
    back={ name="Alaunus's Cape", augments={'MND+20','Eva.+20 /Mag. Eva.+20','MND+10','"Fast Cast"+10','Occ. inc. resist. to stat. ailments+10',}},}
		
	--Melee Curesets are used whenever your Weapons state is set to anything but None.
	sets.midcast.MeleeCure = {ammo="Hydrocera",
		head="Inyanga Tiara +2",neck="Incanter's Torque",ear1="Malignance Earring",ear2="Mendi. Earring",
		body="Theo. Briault +2",hands="Kaykaus Cuffs",ring1="Janniston Ring",ring2="Lebeche Ring",
		back="Alaunus's Cape",waist="Luminary Sash",legs="Ebers Pant. +1",feet="Kaykaus Boots +1"}
		
	sets.midcast.MeleeCureSolace = set_combine(sets.midcast.MeleeCure, {body="Ebers Bliaud +1"})
	sets.midcast.MeleeLightWeatherCure = set_combine(sets.midcast.MeleeCure, {waist="Hachirin-no-Obi"})
	sets.midcast.MeleeLightWeatherCureSolace = set_combine(sets.midcast.MeleeCure, {body="Ebers Bliaud +1",waist="Hachirin-no-Obi"})
	sets.midcast.MeleeLightDayCureSolace = set_combine(sets.midcast.MeleeCure, {body="Ebers Bliaud +1",waist="Hachirin-no-Obi"})
	sets.midcast.MeleeLightDayCure = set_combine(sets.midcast.MeleeCure, {waist="Hachirin-no-Obi"})
	sets.midcast.MeleeCuraga = set_combine(sets.midcast.MeleeCure, {})
	sets.midcast.MeleeLightWeatherCuraga = set_combine(sets.midcast.MeleeCure, {waist="Hachirin-no-Obi"})
	sets.midcast.MeleeLightDayCuraga = set_combine(sets.midcast.MeleeCure, {waist="Hachirin-no-Obi"})

	sets.midcast.CureSolace.DT = set_combine(sets.midcast.Cure.DT, {body="Ebers Bliaud +1"})
	sets.midcast.LightWeatherCure.DT = set_combine(sets.midcast.Cure.DT, {waist="Hachirin-no-Obi"})
	sets.midcast.LightWeatherCureSolace.DT = set_combine(sets.midcast.Cure.DT, {body="Ebers Bliaud +1",waist="Hachirin-no-Obi"})
	sets.midcast.LightDayCureSolace.DT = set_combine(sets.midcast.Cure.DT, {body="Ebers Bliaud +1",waist="Hachirin-no-Obi"})
	sets.midcast.LightDayCure.DT = set_combine(sets.midcast.Cure.DT, {waist="Hachirin-no-Obi"})
	sets.midcast.Curaga.DT = set_combine(sets.midcast.Cure.DT, {})
	sets.midcast.LightWeatherCuraga.DT = set_combine(sets.midcast.Cure.DT, {waist="Hachirin-no-Obi"})
	sets.midcast.LightDayCuraga.DT = set_combine(sets.midcast.Cure.DT, {waist="Hachirin-no-Obi"})
	sets.midcast.MeleeCure.DT = set_combine(sets.midcast.Cure.DT, {})
	
	sets.midcast.MeleeCureSolace.DT = set_combine(sets.midcast.Cure.DT, {body="Ebers Bliaud +1"})
	sets.midcast.MeleeLightWeatherCure.DT = set_combine(sets.midcast.Cure.DT, {waist="Hachirin-no-Obi"})
	sets.midcast.MeleeLightWeatherCureSolace.DT = set_combine(sets.midcast.Cure.DT, {body="Ebers Bliaud +1",waist="Hachirin-no-Obi"})
	sets.midcast.MeleeLightDayCureSolace.DT = set_combine(sets.midcast.Cure.DT, {body="Ebers Bliaud +1",waist="Hachirin-no-Obi"})
	sets.midcast.MeleeLightDayCure.DT = set_combine(sets.midcast.Cure.DT, {waist="Hachirin-no-Obi"})
	sets.midcast.MeleeCuraga.DT = set_combine(sets.midcast.Cure.DT, {})
	sets.midcast.MeleeLightWeatherCuraga.DT = set_combine(sets.midcast.Cure.DT, {waist="Hachirin-no-Obi"})
	sets.midcast.MeleeLightDayCuraga.DT = set_combine(sets.midcast.Cure.DT, {waist="Hachirin-no-Obi"})

	sets.midcast.Cursna = { ammo="Incantor Stone",
    head="Inyanga Tiara +2",
    body="Ebers Bliaud",
    hands={ name="Vanya Cuffs", augments={'MP+50','"Cure" potency +7%','Enmity-6',}},
    legs="Theo. Pantaloons",
    feet={ name="Vanya Clogs", augments={'"Cure" potency +5%','"Cure" spellcasting time -15%','"Conserve MP"+6',}},
    neck={ name="Cleric's Torque", augments={'Path: A',}},
    waist="Witful Belt",
    left_ear="Mendi. Earring",
    right_ear="Nourish. Earring +1",
    left_ring="Ayanmo Ring",
    right_ring="Sirona's Ring",
    back={ name="Alaunus's Cape", augments={'MND+20','Eva.+20 /Mag. Eva.+20','MND+10','"Fast Cast"+10','Occ. inc. resist. to stat. ailments+10',}},}

	sets.midcast.StatusRemoval = {main={ name="Queller Rod", augments={'Healing magic skill +15','"Cure" potency +10%','"Cure" spellcasting time -7%',}},
	ammo="Incantor Stone",
    head={ name="Vanya Hood", augments={'MP+50','"Cure" potency +7%','Enmity-6',}},
    body="Vanya Robe",
    hands="Theophany Mitts +2",
    legs="Ebers Pantaloons",
    feet={ name="Vanya Clogs", augments={'"Cure" potency +5%','"Cure" spellcasting time -15%','"Conserve MP"+6',}},
    neck={ name="Cleric's Torque", augments={'Path: A',}},
    waist="Witful Belt",
    left_ear="Mendi. Earring",
    right_ear="Nourish. Earring +1",
    left_ring="Ayanmo Ring",
    right_ring="Sirona's Ring",
    back={ name="Alaunus's Cape", augments={'MND+20','Eva.+20 /Mag. Eva.+20','MND+10','"Fast Cast"+10','Occ. inc. resist. to stat. ailments+10',}},}

    -- 110 total Enhancing Magic Skill; caps even without Light Arts
	sets.midcast['Enhancing Magic'] = {main="Gada", ammo="Incantor Stone",
    head="Inyanga Tiara +2",
    body="Ebers Bliaud",
    hands="Inyan. Dastanas +2",
    legs="Piety Pantaln. +3",
    feet="Theo. Duckbills +2",
    neck={ name="Cleric's Torque", augments={'Path: A',}},
    waist="Embla Sash",
    left_ear="Mendi. Earring",
    right_ear="Andoaa Earring",
    left_ring="Ayanmo Ring",
    right_ring="Sirona's Ring",
    back={ name="Alaunus's Cape", augments={'MND+20','Eva.+20 /Mag. Eva.+20','MND+10','"Fast Cast"+10','Occ. inc. resist. to stat. ailments+10',}},}

	sets.midcast.Stoneskin = set_combine(sets.midcast['Enhancing Magic'], {neck="Nodens Gorget",ear2="Earthcry Earring",waist="Siegel Sash",legs="Shedir Seraweels"})

	sets.midcast.Auspice = set_combine(sets.midcast['Enhancing Magic'], {feet="Ebers Duckbills +1"})

	sets.midcast.Aquaveil = set_combine(sets.midcast['Enhancing Magic'], {main="Vadose Rod",sub="Ammurapi Shield",hands="Regal Cuffs",waist="Emphatikos Rope",legs="Shedir Seraweels"})

	sets.midcast.Regen = set_combine(sets.midcast['Enhancing Magic'], {main="Bolelabunga",head="Inyanga Tiara +2",body="Piety Briault +3",hands="Ebers Mitts +1",legs="Th. Pantaloons",})
	
	sets.midcast.Protect = set_combine(sets.midcast['Enhancing Magic'], {ring2="Sheltered Ring",feet="Piety Duckbills +1",ear1="Gifted Earring",waist="Embla Sash"})
	sets.midcast.Protectra = set_combine(sets.midcast['Enhancing Magic'], {ring2="Sheltered Ring",feet="Theo. Duckbills +2",ear1="Gifted Earring",waist="Embla Sash"})
	sets.midcast.Shell = set_combine(sets.midcast['Enhancing Magic'], {ring2="Sheltered Ring",legs="Piety Pantaln. +3",ear1="Gifted Earring",waist="Embla Sash"})
	sets.midcast.Shellra = set_combine(sets.midcast['Enhancing Magic'], {ring2="Sheltered Ring",legs="Piety Pantaln. +3",ear1="Gifted Earring",waist="Embla Sash"})
	
	sets.midcast.BarElement = {main="Gada", ammo="Incantor Stone",
    head="Inyanga Tiara +2",
    body="Ebers Bliaud",
    hands="Inyan. Dastanas +2",
    legs="Piety Pantaln. +3",
    feet="theo. duckbills +2",
    neck={ name="Cleric's Torque", augments={'Path: A',}},
    waist="Embla Sash",
    left_ear="Mendi. Earring",
    right_ear="Andoaa Earring",
    left_ring="Ayanmo Ring",
    right_ring="Sirona's Ring",
    back={ name="Alaunus's Cape", augments={'MND+20','Eva.+20 /Mag. Eva.+20','MND+10','"Fast Cast"+10','Occ. inc. resist. to stat. ailments+10',}},}

	sets.midcast.Impact = {main="Maxentius",sub="Ammurapi Shield",ammo="Hydrocera",
		head=empty,neck="Incanter's Torque",ear1="Malignance Earring",ear2="Digni. Earring",
		body="Twilight Cloak",hands=gear.chironic_enfeeble_hands,ring1="Stikini Ring",ring2="Stikini Ring +1",
		back="Toro Cape",waist="Acuity Belt +1",legs="Chironic Hose",feet="Aya. Gambieras +2"}
		
	sets.midcast['Elemental Magic'] = {main="Maxentius",sub="Ammurapi Shield",ammo="Dosis Tathlum",
		head="Buremte Hat",neck="Incanter's Torque",ear1="Malignance Earring",ear2="Friomisi Earring",
		body="Ebers Bliaud +1",hands=gear.chironic_enfeeble_hands,ring1="Shiva Ring +1",ring2="Shiva Ring +1",
		back="Toro Cape",waist=gear.ElementalObi,legs="Chironic Hose",feet="Aya. Gambieras +2"}

	sets.midcast['Elemental Magic'].Resistant = {main="Maxentius",sub="Ammurapi Shield",ammo="Dosis Tathlum",
		head="Buremte Hat",neck="Sanctity Necklace",ear1="Malignance Earring",ear2="Crematio Earring",
		body="Ebers Bliaud +1",hands=gear.chironic_enfeeble_hands,ring1="Shiva Ring +1",ring2="Shiva Ring +1",
		back="Toro Cape",waist="Yamabuki-no-Obi",legs="Chironic Hose",feet="Aya. Gambieras +2"}

	sets.midcast['Divine Magic'] = {main="Gada",sub="Ammurapi Shield",ammo="Hydrocera",
		head="Ipoca Beret",neck="Incanter's Torque",ear1="Malignance Earring",ear2="Digni. Earring",
		body="Inyanga Jubbah +2",hands="Fanatic Gloves",ring1="Stikini Ring",ring2="Stikini Ring +1",
		back="Aurist's Cape +1",waist="Luminary Sash",legs="Chironic Hose",feet="Aya. Gambieras +2"}
		
	sets.midcast.Holy = {main="Gada",sub="Ammurapi Shield",ammo="Hydrocera",
		head="Ipoca Beret",neck="Incanter's Torque",ear1="Malignance Earring",ear2="Friomisi Earring",
		body="Ebers Bliaud +1",hands=gear.chironic_enfeeble_hands,ring1="Shiva Ring +1",ring2="Shiva Ring +1",
		back="Toro Cape",waist=gear.ElementalObi,legs="Gyve Trousers",feet="Aya. Gambieras +2"}

	sets.midcast['Dark Magic'] = {main="Maxentius",sub="Ammurapi Shield",ammo="Hydrocera",
		head="Inyanga Tiara +2",neck="Incanter's Torque",ear1="Malignance Earring",ear2="Digni. Earring",
		body="Inyanga Jubbah +2",hands=gear.chironic_enfeeble_hands,ring1="Stikini Ring",ring2="Stikini Ring +1",
		back="Aurist's Cape +1",waist="Acuity Belt +1",legs="Chironic Hose",feet="Aya. Gambieras +2"}

    sets.midcast.Drain = {main="Maxentius",sub="Ammurapi Shield",ammo="Hydrocera",
        head="Pixie Hairpin +1",neck="Incanter's Torque",ear1="Malignance Earring",ear2="Digni. Earring",
        body="Inyanga Jubbah +2",hands=gear.chironic_enfeeble_hands,ring1="Evanescence Ring",ring2="Archon Ring",
        back="Aurist's Cape +1",waist="Fucho-no-obi",legs="Chironic Hose",feet="Aya. Gambieras +2"}

    sets.midcast.Drain.Resistant = {main="Maxentius",sub="Ammurapi Shield",ammo="Hydrocera",
        head="Inyanga Tiara +2",neck="Incanter's Torque",ear1="Malignance Earring",ear2="Digni. Earring",
        body="Chironic Doublet",hands=gear.chironic_enfeeble_hands,ring1="Stikini Ring",ring2="Stikini Ring +1",
        back="Aurist's Cape +1",waist="Fucho-no-obi",legs="Chironic Hose",feet="Aya. Gambieras +2"}

    sets.midcast.Aspir = sets.midcast.Drain
	sets.midcast.Aspir.Resistant = sets.midcast.Drain.Resistant

	sets.midcast.Stun = {main="Maxentius",sub="Ammurapi Shield",ammo="Hasty Pinion +1",
		head="Nahtirah Hat",neck="Incanter's Torque",ear1="Enchntr. Earring +1",ear2="Loquacious Earring",
		body="Inyanga Jubbah +2",hands="Fanatic Gloves",ring1="Kishar Ring",ring2="Stikini Ring +1",
		back="Aurist's Cape +1",waist="Witful Belt",legs="Lengo Pants",feet="Regal Pumps +1"}

	sets.midcast.Stun.Resistant = {main="Maxentius",sub="Ammurapi Shield",ammo="Hydrocera",
		head="Nahtirah Hat",neck="Incanter's Torque",ear1="Malignance Earring",ear2="Digni. Earring",
		body="Inyanga Jubbah +2",hands="Fanatic Gloves",ring1="Stikini Ring",ring2="Stikini Ring +1",
		back="Aurist's Cape +1",waist="Acuity Belt +1",legs="Chironic Hose",feet="Aya. Gambieras +2"}

	sets.midcast['Enfeebling Magic'] = {main="Gada", ammo="Incantor Stone",
    head={ name="Vanya Hood", augments={'MP+50','"Cure" potency +7%','Enmity-6',}},
    body="Ayanmo Corazza +2",
    hands={ name="Vanya Cuffs", augments={'MP+50','"Cure" potency +7%','Enmity-6',}},
    legs={ name="Vanya Slops", augments={'Healing magic skill +20','"Cure" spellcasting time -7%','Magic dmg. taken -3',}},
    feet={ name="Vanya Clogs", augments={'"Cure" potency +5%','"Cure" spellcasting time -15%','"Conserve MP"+6',}},
    neck="Cleric's Torque",
    waist="Witful Belt",
    left_ear="Mendi. Earring",
    right_ear="Nourish. Earring +1",
    left_ring="Ayanmo Ring",
    right_ring="Sirona's Ring",
    back={ name="Alaunus's Cape", augments={'MND+20','Eva.+20 /Mag. Eva.+20','MND+10','"Fast Cast"+10','Occ. inc. resist. to stat. ailments+10',}},}

	sets.midcast['Enfeebling Magic'].Resistant = {main="Gada",sub="Ammurapi Shield",ammo="Hydrocera",
		head="Inyanga Tiara +2",neck="Incanter's Torque",ear1="Malignance Earring",ear2="Digni. Earring",
		body="Theophany Briault +2",hands="Inyan. Dastanas +2",ring1="Stikini Ring",ring2="Stikini Ring +1",
		back="Aurist's Cape +1",waist="Luminary Sash",legs="Chironic Hose",feet="theo. duckbills +2"}
		
	sets.midcast.Dia = set_combine(sets.midcast['Enfeebling Magic'], sets.TreasureHunter)
	sets.midcast.Diaga = set_combine(sets.midcast['Enfeebling Magic'], sets.TreasureHunter)
	sets.midcast['Dia II'] = set_combine(sets.midcast['Enfeebling Magic'], sets.TreasureHunter)
	sets.midcast.Bio = set_combine(sets.midcast['Enfeebling Magic'], sets.TreasureHunter)
	sets.midcast['Bio II'] = set_combine(sets.midcast['Enfeebling Magic'], sets.TreasureHunter)

    sets.midcast.ElementalEnfeeble = set_combine(sets.midcast['Enfeebling Magic'], {})
    sets.midcast.ElementalEnfeeble.Resistant = set_combine(sets.midcast['Enfeebling Magic'].Resistant, {})

	sets.midcast.IntEnfeebles = set_combine(sets.midcast['Enfeebling Magic'], {waist="Acuity Belt +1"})
	sets.midcast.IntEnfeebles.Resistant = set_combine(sets.midcast['Enfeebling Magic'].Resistant, {waist="Acuity Belt +1"})

	sets.midcast.MndEnfeebles = set_combine(sets.midcast['Enfeebling Magic'], {back="Alaunus's Cape"})
	sets.midcast.MndEnfeebles.Resistant = set_combine(sets.midcast['Enfeebling Magic'].Resistant, {back="Alaunus's Cape",ring1="Stikini Ring +1"})

    -- Sets to return to when not performing an action.

    -- Resting sets
	sets.resting = {main={ name="Queller Rod", augments={'Healing magic skill +15','"Cure" potency +10%','"Cure" spellcasting time -7%',}},
    sub="Sors Shield",
    ammo="Incantor Stone",
    head="Inyanga Tiara +2",
    body="Ebers Bliaut",
    hands="Inyan. Dastanas +2",
    legs="Inyanga Shalwar +2",
    feet="Herald's Gaiters",
    neck="Cleric's Torque",
    waist="Witful Belt",
    left_ear="Mendi. Earring",
    right_ear="Nourish. Earring +1",
    left_ring="Inyanga Ring",
    right_ring="Sirona's Ring",
    back={ name="Alaunus's Cape", augments={'MND+20','Eva.+20 /Mag. Eva.+20','MND+10','"Fast Cast"+10','Occ. inc. resist. to stat. ailments+10',}},}

    -- Idle sets (default idle set not needed since the other three are defined, but leaving for testing purposes)
	sets.idle = {main={ name="Queller Rod", augments={'Healing magic skill +15','"Cure" potency +10%','"Cure" spellcasting time -7%',}},
    sub="Sors Shield",
    ammo="Incantor Stone",
    head="Inyanga Tiara +2",
    body="Ebers Bliaut",
    hands="Inyan. Dastanas +2",
    legs="Inyanga Shalwar +2",
    feet="Herald's Gaiters",
    neck="Cleric's Torque",
    waist="Witful Belt",
    left_ear="Mendi. Earring",
    right_ear="Nourish. Earring +1",
    left_ring="Inyanga Ring",
    right_ring="Warp Ring",
    back={ name="Alaunus's Cape", augments={'MND+20','Eva.+20 /Mag. Eva.+20','MND+10','"Fast Cast"+10','Occ. inc. resist. to stat. ailments+10',}},}

	sets.idle.PDT = {main={ name="Queller Rod", augments={'Healing magic skill +15','"Cure" potency +10%','"Cure" spellcasting time -7%',}},
    sub="Sors Shield",
    ammo="Incantor Stone",
    head="Inyanga Tiara +2",
    body="Ebers Bliaut",
    hands={ name="Vanya Cuffs", augments={'MP+50','"Cure" potency +7%','Enmity-6',}},
    legs="Inyanga Shalwar +2",
    feet="Herald's Gaiters",
    neck="Cleric's Torque",
    waist="Witful Belt",
    left_ear="Mendi. Earring",
    right_ear="Nourish. Earring +1",
    left_ring="Ayanmo Ring",
    right_ring="Sirona's Ring",
    back={ name="Alaunus's Cape", augments={'MND+20','Eva.+20 /Mag. Eva.+20','MND+10','"Fast Cast"+10','Occ. inc. resist. to stat. ailments+10',}},}
		
    sets.idle.Sub = set_combine(sets.idle, {waiste="Embla Sash"})

	sets.idle.Weak = {main={ name="Queller Rod", augments={'Healing magic skill +15','"Cure" potency +10%','"Cure" spellcasting time -7%',}},
    sub="Sors Shield",
    ammo="Incantor Stone",
    head="Inyanga Tiara +2",
    body="Ebers Bliaut",
    hands="Inyan. Dastanas +2",
    legs="Inyanga Shalwar +2",
    feet="Herald's Gaiters",
    neck="Cleric's Torque",
    waist="Witful Belt",
    left_ear="Mendi. Earring",
    right_ear="Nourish. Earring +1",
    left_ring="Inyanga Ring",
    right_ring="Sirona's Ring",
    back={ name="Alaunus's Cape", augments={'MND+20','Eva.+20 /Mag. Eva.+20','MND+10','"Fast Cast"+10','Occ. inc. resist. to stat. ailments+10',}},}

					
    -- Defense sets

	sets.defense.PDT = {main="Bolelabunga",sub="Genbu's Shield",ammo="Staunch Tathlum",
		head="Inyanga Tiara +2",neck="Loricate Torque +1",ear1="Genmei Earring",ear2="Infused Earring",
		body="Vrikodara Jupon",hands="Inyan. Dastanas +2",ring1="Defending Ring",ring2="Stikini Ring +1",
		back="Moonlight Cape",waist="Fucho-no-Obi",legs="Assid. Pants +1",feet="Aya. Gambieras +2"}

	sets.defense.MDT = {main="Mafic Cudgel",sub="Genbu's Shield",ammo="Staunch Tathlum",
		head="Inyanga Tiara +2",neck="Loricate Torque +1",ear1="Genmei Earring",ear2="Sanare Earring",
		body="Inyanga Jubbah +2",hands="Inyan. Dastanas +2",ring1="Defending Ring",ring2="Shadow Ring",
		back="Moonlight Cape",waist="Fucho-no-Obi",legs="Th. Pant. +3",feet="Inyan. Crackows +2"}

    sets.defense.MEVA = {ammo="Staunch Tathlum",
        head="Telchine Cap",neck="Warder's Charm +1",ear1="Genmei Earring",ear2="Sanare Earring",
		body="Inyanga Jubbah +2",hands="Telchine Gloves",ring1="Vengeful Ring",Ring2="Purity Ring",
        back="Aurist's Cape +1",waist="Luminary Sash",legs="Telchine Braconi",feet="Telchine Pigaches"}
		
	-- Gear for specific elemental nukes.
	sets.element.Wind = {main="Marin Staff +1"}
	sets.element.Ice = {main="Ngqoqwanb"}
	sets.element.Earth = {neck="Quanpur Necklace"}
	
	
	-- Sublimation
	    sets.buff.FullSublimation = set_combine(sets.idle,{waist="Embla Sash"})
		sets.buff.PDTSublimation = {}
		
		-- Engaged sets

    -- Variations for TP weapon and (optional) offense/defense modes.  Code will fall back on previous
    -- sets if more refined versions aren't defined.
    -- If you create a set with both offense and defense modes, the offense mode should be first.
    -- EG: sets.engaged.Dagger.Accuracy.Evasion

    -- Basic set for if no TP weapon is defined.
    sets.engaged = {main={ name="Queller Rod", augments={'Healing magic skill +15','"Cure" potency +10%','"Cure" spellcasting time -7%',}},
    sub="Sors Shield",
    ammo="Incantor Stone",
    head="Aya. Zucchetto +2",
    body="Ayanmo Corazza +2",
    hands="Aya. Manopolas +2",
    legs="Aya. Cosciales +2",
    feet="Aya. Gambieras +2",
    neck={ name="Cleric's Torque", augments={'Path: A',}},
    waist="Witful Belt",
    left_ear="Mendi. Earring",
    right_ear="Nourish. Earring +1",
    left_ring="Ayanmo Ring",
    right_ring="Sirona's Ring",
    back={ name="Alaunus's Cape", augments={'MND+20','Eva.+20 /Mag. Eva.+20','MND+10','"Fast Cast"+10','Occ. inc. resist. to stat. ailments+10',}},}

    sets.engaged.Acc = {main={ name="Queller Rod", augments={'Healing magic skill +15','"Cure" potency +10%','"Cure" spellcasting time -7%',}},
    sub="Sors Shield",
    ammo="Incantor Stone",
    head="Aya. Zucchetto +2",
    body="Ayanmo Corazza +2",
    hands="Aya. Manopolas +2",
    legs="Aya. Cosciales +2",
    feet="Aya. Gambieras +2",
    neck={ name="Cleric's Torque", augments={'Path: A',}},
    waist="Witful Belt",
    left_ear="Mendi. Earring",
    right_ear="Nourish. Earring +1",
    left_ring="Ayanmo Ring",
    right_ring="Sirona's Ring",
    back={ name="Alaunus's Cape", augments={'MND+20','Eva.+20 /Mag. Eva.+20','MND+10','"Fast Cast"+10','Occ. inc. resist. to stat. ailments+10',}},}

	sets.engaged.DW = {main="Yagrush",ammo="Staunch Tathlum",
        head="Aya. Zucchetto +2",neck="Asperity Necklace",ear1="Telos Earring",ear2="Suppanomimi",
		body="Ayanmo Corazza +2",hands="Aya. Manopolas +2",ring1="Petrov Ring",Ring2="Ilabrat Ring",
        back="Kayapa Cape",waist="Shetal Stone",legs="Aya. Cosciales +2",feet="Battlecast Gaiters"}

    sets.engaged.DW.Acc = {ammo="Hasty Pinion +1",
        head="Aya. Zucchetto +2",neck="Combatant's Torque",ear1="Telos Earring",ear2="Suppanomimi",
		body="Ayanmo Corazza +2",hands="Aya. Manopolas +2",ring1="Petrov Ring",Ring2="Ilabrat Ring",
        back="Kayapa Cape",waist="Shetal Stone",legs="Aya. Cosciales +2",feet="Aya. Gambieras +2"}

		-- Buff sets: Gear that needs to be worn to actively enhance a current player buff.
    sets.buff['Divine Caress'] = {hands="Ebers Mitts +1",back="Mending Cape"}
	
	sets.HPDown = {head="Pixie Hairpin +1",ear1="Mendicant's Earring",ear2="Evans Earring",
		body="Zendik Robe",hands="Hieros Mittens",ring1="Mephitas's Ring +1",ring2="Mephitas's Ring",
		back="Swith Cape +1",waist="Fucho-no-Obi",legs="Shedir Seraweels",feet=""}

	sets.HPCure = {main="Queller Rod",sub="Sors Shield",ammo="Impatiens",
		head="Kaykaus Mitra +1",neck="Loricate Torque +1",ear1="Glorious Earring",ear2="Mendi. Earring",
		body="Ebers Bliaud +1",hands="Theophany Mitts +3",ring1="Lebeche Ring",ring2="Stikini Ring +1",
		back="Alaunus's Cape",waist="Hachirin-no-Obi",legs="Ebers Pant. +1",feet="Kaykaus Boots +1"}

	sets.buff.Doom = set_combine(sets.buff.Doom, {})

end



-- Select default macro book on initial load or subjob change.
function select_default_macro_book()
	set_macro_page(1, 1)
end