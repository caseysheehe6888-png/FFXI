function user_setup()

	-- Options: Override default values
    state.OffenseMode:options('Normal', 'PDT', 'Acc')
	state.CastingMode:options('Normal', 'Resistant')
    state.IdleMode:options('Normal', 'PDT')
	state.PhysicalDefenseMode:options('PDT')
	state.MagicalDefenseMode:options('MDT')
	state.ResistDefenseMode:options('MEVA')
	state.Weapons:options('None','Tishtrya')

--Auto Buff Defaults (Window Key + Pause/Break)

	autoindi = "Fury"
	autogeo = "Frailty"
	autoentrust = 'Haste'
	autoentrustee = 'Rizze'

	-- Additional local binds
	send_command('bind ^q gs c cycle ElementalMode')
--	send_command('bind !` input /ja "Full Circle" <me>')
	send_command('bind @f8 gs c toggle AutoNukeMode')
	send_command('bind ` gs c cycle MagicBurstMode')
	send_command('bind ^` gs c cycle Weapons')	
	send_command('bind ^@!` gs c toggle AutoEntrust')

	--	send_command('bind @f10 gs c cycle RecoverMode')
--	send_command('bind ^backspace input /ja "Entrust" <me>')
--	send_command('bind !backspace input /ja "Life Cycle" <me>')
--	send_command('bind @backspace input /ma "Sleep II" <t>')
--	send_command('bind ^delete input /ma "Aspir III" <t>')
--	send_command('bind @delete input /ma "Sleep" <t>')
	
	indi_duration = 290
	
	select_default_macro_book()
    set_lockstyle()
	
end

function init_gear_sets()
	
	--------------------------------------
	-- Precast sets
	--------------------------------------

	-- Weapons sets
	sets.weapons.Tishtrya = {main="Tishtrya",sub="Genmei Shield"}


	-- Precast sets to enhance JAs
	sets.precast.JA.Bolster = {body="Bagua Tunic +1"}
	sets.precast.JA['Life Cycle'] = {body="Geomancy Tunic +3",back={ name="Nantosuelta's Cape", augments={'HP+60','Eva.+20 /Mag. Eva.+20','Pet: "Regen"+10','Pet: "Regen"+5',}},}
	sets.precast.JA['Radial Arcana'] = {feet="Bagua Sandals +1"}
	sets.precast.JA['Mending Halation'] = {legs="Bagua Pants +1"}
	sets.precast.JA['Full Circle'] = {head="Azimuth Hood +1",hands="Bagua Mitaines +3",body="Geomancy Tunic +3",back="Nantosuelta's Cape"}
    sets.precast.JA['Curative Recantation'] = {hands="Bagua Mitaines +3"}
    sets.precast.JA['Primal Zeal'] = {head="Bagua Galero +1"}   
    sets.precast.JA['Cardinal Chant'] = {head="Geomancy Galero +2"}	
	
	-- Indi Duration in slots that would normally have skill here to make entrust more efficient.
	sets.buff.Entrust = {}
	
	-- Fast cast sets for spells

    sets.precast.FC = {
		main="Solstice",													-- 5%
		sub="Genmei shield",
		range="Dunna",														-- 3%
		ammo=empty,
		head="Vanya Hood", 													-- 10%
		body="Amalric Doublet +1",												-- 5%
		hands={ name="Merlinic Dastanas", augments={'"Mag.Atk.Bns."+12','"Fast Cast"+5','INT+4','Mag. Acc.+10',}},	-- 5%
		legs="Geomancy Pants +2",												-- 11%
		feet="Amalric Nails +1",											-- 6%
		neck="Voltsurge torque",											-- 4%
		waist="Witful Belt",												-- 3%
		ear1="Loquac. Earring",												-- 2%
		ear2="Enchntr. Earring +1",											-- 2%
		ring1="Kishar Ring",												-- 4%
		ring2="Rahab Ring",													-- 2%
		back="Lifestream Cape",												-- 7%

}

	sets.precast.FC.Geomancy = set_combine(sets.precast.FC, {})
    sets.precast.FC['Elemental Magic'] = set_combine(sets.precast.FC, {hands="Bagua Mitaines +3",ear2="Barkaro. Earring"})
	sets.precast.FC.Cure = set_combine(sets.precast.FC, {
		main="Solstice",
		sub="Sors Shield",
		head="Vanya Hood",
		body="Vanya Robe",
		hands="Vanya Cuffs",
		legs="Vanya Slops",
		feet="Vanya Clogs",
		neck="Incanter's Torque",
		ear1="Loquacious Earring",
		ear2="Mendi. Earring",
        ring1="Kishar Ring",
		ring2="Rahab Ring",
		back="Pahtli Cape",
	})

	sets.precast.FC.Curaga = sets.precast.FC.Cure
	
	sets.precast.FC.Impact = set_combine(sets.precast.FC, {head=empty,body="Twilight Cloak"})

	sets.Self_Healing = {}
	sets.Cure_Received = {}
	sets.Self_Refresh = {}
	
    sets.precast.FC['Enhancing Magic'] = set_combine(sets.precast.FC, {waist="Siegel Sash"})
    sets.precast.FC.Stoneskin = set_combine(sets.precast.FC['Enhancing Magic'], {hands="Carapacho Cuffs"})
	

	--------------------------------------
	-- Midcast sets
	--------------------------------------

    sets.midcast.FastRecast = set_combine(sets.precast.FC,{})

    sets.midcast.Geomancy ={
		main="Solstice", --Idris
		sub="Genmei Shield",
		range="Dunna",
		ammo=empty,
		head="Azimuth Hood +1",
		body="Bagua Tunic +1",
		hands="Geo. Mitaines +2",
		legs="Bagua Pants +1",
		feet="Azimuth Gaiters +1",
		neck="Bagua Charm +2",
		waist="Fucho-no-Obi",
		ring1="Renaye Ring",
		ring2={ name="Stikini Ring +1", bag="wardrobe4"},
		back="Lifestream Cape", 
}

	--Extra Indi duration as long as you can keep your 900 skill cap.
	sets.midcast.Geomancy.Indi = set_combine(sets.midcast.Geomancy, {feet="Azimuth Gaiters +1",})
		
    sets.midcast.Cure = {
		main="Tamaxchi",
		sub="Sors Shield",
		--ammo="Hydrocera",
		head="Vanya Hood",
		body="Vanya Robe",
		hands="Vanya Cuffs",
		legs="Vanya Slops",
		feet="Vanya Clogs",
		neck="Incanter's Torque",
		waist="Bishop's Sash",
		ear1="Beatific Earring",
		ear2="Mendi. Earring",
		ring1="Sirona's Ring",
		ring2="Ephdera Ring",
		back="Pahtli Cape",
}
		
    sets.midcast.LightWeatherCure = set_combine(sets.midcast.Cure,{})
		
--Cureset for if it's not light weather but is light day.
    sets.midcast.LightDayCure = set_combine(sets.midcast.Cure,{})
    sets.midcast.Curaga = set_combine(sets.midcast.Cure,{})
	
	sets.midcast.Cursna =  set_combine(sets.midcast.Cure,{back="Oretan. Cape +1",})
	
	sets.midcast.StatusRemoval = set_combine(sets.midcast.FastRecast, {})
	
	sets.midcast.Impact = set_combine(sets.midcast['Elemental Magic'],{
		head=empty,
		body="Twilight Cloak",
		hands="Geo. Mitaines +2",
		legs="Geomancy Pants +2",
		feet="Azimuth Gaiters +1",
		neck="Bagua Charm +2",
		waist="Luminary Sash",
		ear1="Regal Earring",
		ear2="Digni. Earring",
		ring1="Renaye Ring",
		ring2={ name="Stikini Ring +1", bag="wardrobe4"},
		back={ name="Nantosuelta's Cape", augments={'INT+20','Mag. Acc+20 /Mag. Dmg.+20','INT+10','"Mag.Atk.Bns."+10',}},
	})
	
    sets.midcast['Elemental Magic']= {
		main={ name="Grioavolr", augments={'Magic burst dmg.+2%','MP+58','Mag. Acc.+8','"Mag.Atk.Bns."+23','Magic Damage +8',}},
		sub="Enki Strap",
		ammo="Pemphredo Tathlum",
		head={ name="Merlinic Hood", augments={'Mag. Acc.+24 "Mag.Atk.Bns."+24','INT+5','Mag. Acc.+8','"Mag.Atk.Bns."+13',}},
        body="Amalric Doublet +1",
        hands="Amalric Gages +1",
        legs="Amalric Slops +1",
		feet="Amalric Nails +1",
		neck="Sanctity Necklace",
		waist="Eschan Stone",
		ear1="Regal Earring",
		ear2="Friomisi Earring",
		ring1="Fenrir ring",
		ring2="Fenrir ring",
		back={ name="Nantosuelta's Cape", augments={'INT+20','Mag. Acc+20 /Mag. Dmg.+20','INT+10','"Mag.Atk.Bns."+10',}},
	}

    sets.MagicBurst = set_combine(sets.midcast['Elemental Magic'],{
		head="Ea Hat",
		body="Ea Houppelande",
		hands="Amalric Gages +1",
		legs="Ea slops",
		feet="Ea Pigaches",
		neck="Mizu. Kubikazari", 
		ring1="Mujin Band",
		ring2="Locus Ring",
	})

    sets.midcast['Elemental Magic'].Resistant = set_combine(sets.midcast['Elemental Magic'],{
	
	})

    sets.midcast['Dark Magic'] = {
		main="Rubicundity",
		sub="Ammurapi shield",
		head="Bagua Galero +1",
		body="Bagua Tunic +1",
		hands="Geo. Mitaines +2",
		legs="Geomancy Pants +2",
		feet="Geo. Sandals +2",
		neck="Erra Pendant",
		waist="Fucho-no-Obi",
		ear1="Regal Earring",
		ear2="Enchanter Earring +1",
        ring1="Evanescence ring",
        ring2="Archon Ring",
		back="Perimede Cape",
}
		
    sets.midcast.Drain = set_combine(sets.midcast['Dark Magic'],{ear2="Hirudinea Earring"})
    sets.midcast.Aspir = set_combine(sets.midcast['Dark Magic'],{ear2="Hirudinea Earring"})
	sets.midcast.Stun = set_combine(sets.midcast['Dark Magic'],{})
	sets.midcast.Stun.Resistant = set_combine(sets.midcast['Dark Magic'],{})
		
    sets.midcast['Enfeebling Magic'] = {
		main="Idris",
		sub="Ammurapi Shield",
		head="Befouled Crown",
		body="Geomancy Tunic +3",
		hands="Geo. Mitaines +2",
		legs="Geomancy Pants +2",
		feet="Bagua Sandals +1",
		neck="Bagua Charm +2",
		waist="Rumination Sash",
		ear1="Regal Earring",
		ear2="Digni. Earring",
		ring1="Renaye Ring",
		ring2={ name="Stikini Ring +1", bag="wardrobe4"},
		back={ name="Nantosuelta's Cape", augments={'INT+20','Mag. Acc+20 /Mag. Dmg.+20','INT+10','"Mag.Atk.Bns."+10',}},

	}
		
	sets.midcast['Enfeebling Magic'].Resistant = set_combine(sets.midcast['Enfeebling Magic'],{})
		
    sets.midcast.ElementalEnfeeble = set_combine(sets.midcast['Enfeebling Magic'],{})
    sets.midcast.ElementalEnfeeble.Resistant = set_combine(sets.midcast['Enfeebling Magic'],{})
	
	sets.midcast.IntEnfeebles = set_combine(sets.midcast['Enfeebling Magic'],{})
	sets.midcast.IntEnfeebles.Resistant = set_combine(sets.midcast['Enfeebling Magic'],{})
	
	sets.midcast.MndEnfeebles = set_combine(sets.midcast['Enfeebling Magic'],{})
	sets.midcast.MndEnfeebles.Resistant = set_combine(sets.midcast['Enfeebling Magic'],{})
	
	sets.midcast.Dia = set_combine(sets.midcast['Enfeebling Magic'],{})
	sets.midcast['Dia II'] = set_combine(sets.midcast['Enfeebling Magic'],{})
	
	sets.midcast.Bio = set_combine(sets.midcast['Enfeebling Magic'],{})
	sets.midcast['Bio II'] = set_combine(sets.midcast['Enfeebling Magic'],{})
	
	sets.midcast['Divine Magic'] = set_combine(sets.midcast['Enfeebling Magic'],{})
		
    sets.midcast['Enhancing Magic']=set_combine(sets.idle,{
		main="Gada",
		sub="Ammurapi shield",
        head="Telchine Cap",
        body="Telchine Chas.",
        hands="Telchine Gloves",
        legs=" Telchine Braconi",
        feet="Telchine Pigaches",
		neck="Incanter's Torque",
		waist="Olympus Sash",
		ear1="Andoaa Earring",
		ear2="Mendi. Earring",
		ring1="Renaye Ring",
		ring2={ name="Stikini Ring +1", bag="wardrobe4"},
		back="Perimede Cape"
})

	sets.midcast.Stoneskin = set_combine(sets.midcast['Enhancing Magic'], {neck="Nodens Gorget",ear2="Earthcry Earring",legs="Haven Hose",waist="Siegel Sash"})
	sets.midcast.Phalanx = set_combine(sets.precast.FC['Enhancing Magic'], {})
	sets.midcast.Refresh = set_combine(sets.midcast['Enhancing Magic'], {}) --head="Amalric Coif +1"
	sets.midcast.Aquaveil = set_combine(sets.midcast['Enhancing Magic'], {}) --head="Amalric Coif +1"
	sets.midcast.BarElement = set_combine(sets.precast.FC['Enhancing Magic'], {})	
	sets.midcast.Protect = set_combine(sets.precast.FC['Enhancing Magic'], {})
	sets.midcast.Protectra = set_combine(sets.precast.FC['Enhancing Magic'], {})
	sets.midcast.Shell = set_combine(sets.precast.FC['Enhancing Magic'], {})
	sets.midcast.Shellra = set_combine(sets.precast.FC['Enhancing Magic'], {})

	-- Gear for specific elemental nukes.
	sets.element.Wind = {}
	sets.element.Ice = {}
	sets.element.Earth = {}

	--------------------------------------
	-- Idle/resting/defense/etc sets
	--------------------------------------

	-- Resting sets

	sets.resting = set_combine(sets.idle,{})

    sets.idle = {
		main="Bolelabunga", --Idris
		sub="Genmei Shield",
		range="Dunna",
		head="Befouled Crown", --Befouled Crown
		body="Jhakri Robe +2",
		hands="Bagua Mitaines +3",
		legs="Assid. Pants +1",
		feet="Merlinic Crackows",
		neck="Loricate Torque +1",
		waist="Fucho-no-Obi",
		ear1="Handler's Earring",
		ear2="Handler's Earring +1",
		ring1="Renaye Ring",
		ring2="Stikini Ring +1",
		back={ name="Nantosuelta's Cape", augments={'HP+60','Eva.+20 /Mag. Eva.+20','Pet: "Regen"+10','Pet: "Regen"+5',}}, 
}


--	sets.idle.TPEat = set_combine(sets.idle, {})
--  .Pet sets are for when Luopan is present.
	sets.idle.Pet = set_combine(sets.idle,{
		main="Idris",
		sub="Genmei shield",
		range="Dunna",
		ammo=empty,
		head="Azimuth Hood +1",
        body="Telchine Chas.",
		hands="Telchine Gloves",
        legs="Telchine Braconi",
		feet="Bagua Sandals +1",
		neck="Bagua Charm +2",
		waist="Isa Belt",
		ear1="Handler's Earring",
		ear2="Handler's Earring +1",
		ring1="Renaye Ring",
		ring2={ name="Stikini Ring +1", bag="wardrobe4"},
		back={ name="Nantosuelta's Cape", augments={'HP+60','Eva.+20 /Mag. Eva.+20','Pet: "Regen"+10','Pet: "Regen"+5',}}, 

	})
	
	sets.idle.PDT = set_combine(sets.idle, {}) 
	
	sets.idle.PDT.Pet = set_combine(sets.idle.Pet, {}) 


	-- .Indi sets are for when an Indi-spell is active.
	sets.idle.Indi = set_combine(sets.idle, {}) 
	sets.idle.Pet.Indi = set_combine(sets.idle.Pet, {}) 
	sets.idle.PDT.Indi = set_combine(sets.idle.PDT, {}) 
	sets.idle.PDT.Pet.Indi = set_combine(sets.idle.PDT.Pet, {})

	sets.idle.Weak = set_combine(sets.idle,{})

	-- Defense sets
	
	sets.defense.PDT = set_combine(sets.idle.Pet,{})
	sets.defense.MDT = set_combine(sets.defense.PDT,{})
    sets.defense.MEVA = set_combine(sets.defense.PDT,{})	

	sets.Town = set_combine(sets.idle,{
		neck="Bagua Charm +2",
		head="Ea Hat",
		body="Ea Houppelande",
		legs="Amalric Gages",
		feet="Ea Pigaches",}
	)
	sets.Kiting = {feet="Geo. Sandals +2"}
	sets.latent_refresh = {waist="Fucho-no-obi"}
	sets.DayIdle = {}
	sets.NightIdle = {}
	sets.TreasureHunter = {}
	sets.HPDown = set_combine(sets.idle,{})
	
	sets.buff.Doom = set_combine(sets.midcast.Cure, {
		waist="Gishdubar Sash",
		ring1={ name="Eshmun's Ring", bag="wardrobe3"},
		ring2={ name="Eshmun's Ring", bag="wardrobe4"},
		back="Oretan. Cape +1",
	})

	--------------------------------------
	-- Engaged sets
	--------------------------------------

	-- Variations for TP weapon and (optional) offense/defense modes.  Code will fall back on previous
	-- sets if more refined versions aren't defined.
	-- If you create a set with both offense and defense modes, the offense mode should be first.
	-- EG: sets.engaged.Dagger.Accuracy.Evasion

	--Capacity Points Party
	
	sets.engaged = sets.idle.Pet
	
	-- Normal melee group
	
	--[[
	
	sets.engaged = set_combine(sets.idle.Pet,{
		main="Tishtrya",
		sub="Genmei shield",
		head="Bagua Galero +1",
		body="Bagua Tunic +1",
		hands="Bagua Mitaines +3",
		legs="Bagua Pants +1",
		feet="Bagua Sandals +1",
		neck="Loricate torque +1",
		ring1="Defending Ring",
		back={ name="Nantosuelta's Cape", augments={'HP+60','Eva.+20 /Mag. Eva.+20','Pet: "Regen"+10','Pet: "Regen"+5',}}, 

	}) 
	
	]]
		
	sets.engaged.DW = set_combine(sets.engaged,{})
	sets.engaged.Acc = set_combine(sets.engaged,{})
	sets.engaged.PDT = sets.idle.Pet

	-- Weaponskill sets
	-- Default set for any weaponskill that isn't any more specifically defined
	sets.precast.WS = set_combine(sets.engaged.Acc,{
		neck="Fotia gorget",
		waist="Fotia belt",
	})

	--------------------------------------
	-- Custom buff sets
	--------------------------------------
	
	-- Gear that converts elemental damage done to recover MP.	
	sets.RecoverMP = {}
	
	-- Gear for Magic Burst mode.
	sets.RecoverBurst = set_combine(sets.midcast['Elemental Magic'],{
		head="Ea Hat",
		body="Ea Houppelande",
		hands="Amalric Gages +1",
		legs="Amalric Gages",
		feet="Jhakri Pigaches +2", -- Ea Pigaches 
		neck="Mizu. Kubikazari", 
		ring1="Mujin Band",
		ring2="Locus Ring"
		})
	
	--= {neck="Mizu. Kubikazari",ring1="Mujin Band",feet="Jhakri Pigaches +2"}

end

-- Select default macro book on initial load or subjob change.
function select_default_macro_book()
	set_macro_page(1, 1)
end
function set_lockstyle()
    send_command('wait 2; input /lockstyleset 8')
end

buff_spell_lists = {
	Auto = {	
		{Name='Haste',		Buff='Haste',		SpellID=57,		When='Always'},
		{Name='Refresh',	Buff='Refresh',		SpellID=109,	When='Always'},
		{Name='Stoneskin',	Buff='Stoneskin',	SpellID=54,		When='Always'},
		{Name='Blink',		Buff='Blink',		SpellID=53,		When='Always'},
		{Name='Phalanx',	Buff='Phalanx',		SpellID=106,	When='Always'},
	},
	
	Default = {
		{Name='Haste',		Buff='Haste',		SpellID=57,		Reapply=false},
		{Name='Refresh',	Buff='Refresh',		SpellID=109,	Reapply=false},
		{Name='Aquaveil',	Buff='Aquaveil',	SpellID=55,		Reapply=false},
		{Name='Stoneskin',	Buff='Stoneskin',	SpellID=54,		Reapply=false},
		{Name='Blink',		Buff='Blink',		SpellID=53,		Reapply=false},
		{Name='Regen',		Buff='Regen',		SpellID=108,	Reapply=false},
		{Name='Phalanx',	Buff='Phalanx',		SpellID=106,	Reapply=false},
	},
}

--[[ return {
    ["Bozzetto Breadwinner"]={
        ["Fire Meeble Warble"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]="input /ma Barfira <me>"}, 
        ["Aero Meeble Warble"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]="input /ma Baraera <me>"
        }, 
        ["Water Meeble Warble"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]="input /ma Barwatera <me>"
        }, 
        ["Blizzard Meeble Warble"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]="input /ma Barblizzara <me>"
        }, 
        ["Stone Meeble Warble"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]="input /ma Barstonra <me>"
        }, 
        ["Thunder Meeble Warble"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]="input /ma Barthundra <me>"
        }
    }} ]]