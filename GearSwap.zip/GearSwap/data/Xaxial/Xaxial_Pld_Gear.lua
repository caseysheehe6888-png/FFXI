function user_setup()

    -- Options: Override default values	
	state.OffenseMode:options('Normal','DD','Aegis')
    state.HybridMode:options('Normal','Tank','DD')
    state.WeaponskillMode:options('Match','Normal', 'Acc')
    state.CastingMode:options('Normal')
    state.PhysicalDefenseMode:options('PDT', 'PDT_HP')
    state.MagicalDefenseMode:options('MDT', 'MDT_HP')
	state.ResistDefenseMode:options('MEVA', 'MEVA_HP')
	state.IdleMode:options('Kite','PDT','MDT','DD','Reraise')
	state.Weapons:options('Burt','Caladbolg','Ragnarok','DD','none')
	
    state.ExtraDefenseMode = M{['description']='Extra Defense Mode','None','Aegis2','Ochain2'}
	
	autows='Atonement'
	
	-- Additional local binds
	send_command('bind ^` gs c cycle Weapons')
	send_command('bind ^f7 gs c cycleback Weapons')	
	send_command('bind ^@!` gs c SubJobEnmity')
--	send_command('bind ^backspace input /ja "Shield Bash" <t>')
--	send_command('bind @backspace input /ja "Cover" <stpt>')
--	send_command('bind !backspace input /ja "Sentinel" <me>')
--	send_command('bind @= input /ja "Chivalry" <me>')
--	send_command('bind != input /ja "Palisade" <me>')
--	send_command('bind ^delete input /ja "Provoke" <stnpc>')
--	send_command('bind !delete input /ma "Cure IV" <stal>')
--	send_command('bind @delete input /ma "Flash" <stnpc>')
--  send_command('bind ` gs c toggle IdleMode')
--	send_command('bind ` gs c toggle EquipShield')
--	send_command('bind @` gs c cycle RuneElement')
--	send_command('bind @pause gs c toggle AutoRuneMode')
	send_command('bind @` gs c toggle AutoTankMode')
	send_command('bind !` gs c cycle SkillchainMode')
	
    select_default_macro_book()
    update_defense_mode()
	set_lockstyle()
end

function init_gear_sets()
	
	sets.TreasureHunter = set_combine(sets.TreasureHunter, {Ammo="Perfect Lucky Egg",feet="Volte Boots",belt="Chaac Belt",head="White Rarab Cap +1"})
	
	-- Weapons sets
	sets.weapons.Caladbolg = {main="Caladbolg",sub="Tzacab Grip"}
	sets.weapons.Ragnarok = {main="Ragnarok",sub="Tzacab Grip"}
	sets.weapons.Burt = {main="Burtgang",sub="Priwen"}
	sets.weapons.DD = {main="Naegling",sub="Blurred Shield +1"}
	sets.weapons.none = {main="",sub=""}

	--------------------------------------
	-- Precast sets
	--------------------------------------
		
    sets.Enmity = {ammo="Staunch Tathlum",
        head="Caballarius Coronet +3",neck="Knight's Bead Necklace +1",ear1="Friomisi Earring",ear2="Trux Earring",
        body="Souv. Cuirass +1",hands="Caballarius Gauntlets +3",ring1="Eihwaz Ring",ring2="Petrov Ring",
        back="Rudianos's Mantle",waist="Creed Baudrier",legs="Caballarius Breeches +2",feet="Souveran Schuhs +1"}
	

    sets.Enmity.DT = set_combine(sets.Enmity,{
		ammo="Staunch Tathlum",
		hands="Souv. Handsch. +1",
		ear1="Odnowa Earring +1",
		ear2="Odnowa Earring",
        ring1="Defending Ring",
		ring2="Moonbeam Ring",
		})
		
    -- Precast sets to enhance JAs
    sets.precast.JA['Invincible'] = set_combine(sets.Enmity,{legs="Caballarius Breeches +3"})
    sets.precast.JA['Holy Circle'] = set_combine(sets.Enmity,{feet="Rev. Leggings +1"})
    sets.precast.JA['Sentinel'] = set_combine(sets.Enmity,{feet="Caballarius Leggings +3"})
	sets.precast.JA['Provoke'] = set_combine(sets.Enmity,{})
    sets.precast.JA['Rampart'] = set_combine(sets.Enmity,{head="Caballarius Coronet +3"})
    
	sets.precast.JA['Fealty'] = set_combine(sets.Enmity,{body="Caballarius Surcoat +3"})
    sets.precast.JA['Divine Emblem'] = set_combine(sets.Enmity,{feet="Chev. Sabatons"})
    sets.precast.JA['Cover'] = set_combine(sets.Enmity, {head="Rev. Coronet +1",body="Cab. Surcoat +3"})
	
    sets.precast.JA['Invincible'].DT = set_combine(sets.Enmity.DT,{legs="Caballarius Breeches +3"})
    sets.precast.JA['Holy Circle'].DT = set_combine(sets.Enmity.DT,{feet="Rev. Leggings +3"})
    sets.precast.JA['Sentinel'].DT = set_combine(sets.Enmity.DT,{feet="Caballarius Leggings +3"})
    
	sets.precast.JA['Rampart'].DT = set_combine(sets.Enmity.DT,{head="Caballarius Coronet +3"}) 
    
	sets.precast.JA['Fealty'].DT = set_combine(sets.Enmity.DT,{body="Caballarius Surcoat +3"})
    sets.precast.JA['Divine Emblem'].DT = set_combine(sets.Enmity.DT,{feet="Chev. Sabatons"})
    sets.precast.JA['Cover'].DT = set_combine(sets.Enmity.DT, {head="Rev. Coronet +1",body="Caballarius Surcoat +3"})
	
    -- add mnd for Chivalry
    sets.precast.JA['Chivalry'] = set_combine(sets.Enmity, {hands="Caballarius Gauntlets +3"})	

	sets.precast.JA['Shield Bash'] = set_combine(sets.Enmity, {sub="Aegis",hands="Caballarius Gauntlets +3"})		
    sets.precast.JA['Provoke'] = set_combine(sets.Enmity, {})
	sets.precast.JA['Warcry'] = set_combine(sets.Enmity, {})
	sets.precast.JA['Palisade'] = set_combine(sets.Enmity, {})
	sets.precast.JA['Intervene'] = set_combine(sets.Enmity, {})
	sets.precast.JA['Defender'] = set_combine(sets.Enmity, {})
	sets.precast.JA['Berserk'] = set_combine(sets.Enmity, {})
	sets.precast.JA['Aggressor'] = set_combine(sets.Enmity, {})
	
	sets.precast.JA['Shield Bash'].DT = set_combine(sets.Enmity.DT, {sub="Aegis",hands="Caballarius Gauntlets +3"})		
    sets.precast.JA['Provoke'].DT = set_combine(sets.Enmity.DT, {})
	sets.precast.JA['Warcry'].DT = set_combine(sets.Enmity.DT, {})
	sets.precast.JA['Palisade'].DT = set_combine(sets.Enmity.DT, {})
	sets.precast.JA['Intervene'].DT = set_combine(sets.Enmity.DT, {})
	sets.precast.JA['Defender'].DT = set_combine(sets.Enmity.DT, {})
	sets.precast.JA['Berserk'].DT = set_combine(sets.Enmity.DT, {})
	sets.precast.JA['Aggressor'].DT = set_combine(sets.Enmity.DT, {})

    -- Waltz set (chr and vit)
    sets.precast.Waltz = {}
    sets.precast.Waltz['Healing Waltz'] = {}
    sets.precast.Step = {}
	sets.precast.JA['Violent Flourish'] = {}
	sets.precast.JA['Animated Flourish'] = set_combine(sets.Enmity, {})

    -- Fast cast sets for spells
    
    sets.precast.FC = {
	ammo="Sapience Orb",
    head="Sakpata's Helm",
    body="Odyssean Chestplate",
    hands="Leyline Gloves",
    legs="Caballarius Breeches +3",
    feet="Caballarius Leggings +3",
    neck="Incanter's Torque",
    waist="Eschan Stone",
    left_ear="Loquac. Earring",
    right_ear="Thureous Earring",
    left_ring="Rahab Ring",
    right_ring="Kishar Ring",
    back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','Mag. Evasion+10','"Fast Cast"+10','Damage taken-5%',}},
	}
		
    sets.precast.FC.DT = {
		ammo="Staunch Tathlum",
    head={ name="Souv. Schaller +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
    body={ name="Cab. Surcoat +3", augments={'Enhances "Fealty" effect',}},
    hands={ name="Souv. Handsch. +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
   legs={ name="Souv. Diechlings +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
    feet={ name="Souveran Schuhs +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
    neck="Incanter's Torque",
    waist="Eschan Stone",
    left_ear="Loquac. Earring",
    right_ear="Thureous Earring",
    left_ring="Defending Ring",
    right_ring="Moonbeam Ring",
    back={ name="Rudianos's Mantle", augments={'HP+60','Accuracy+20 Attack+20','Accuracy+6','Enmity+10','Phys. dmg. taken-8%',}},
	}
		
    sets.precast.FC['Enhancing Magic'] = set_combine(sets.precast.FC, {waist="Siegel Sash"})
	
	sets.precast.FC['Blue Magic'] = set_combine(sets.precast.FC, {})
	
	sets.precast.FC.Cure = {
	ammo="Sapience Orb",
    head="Sakpata's Helm",
    body="Odyssean Chestplate",
    hands="Leyline Gloves",
    legs="Caballarius Breeches +3",
    feet="Caballarius Leggings +3",
    neck="Diemer Gorget",
    waist="Eschan Stone",
    left_ear="Nourishing Earring +1",
    right_ear="Mendicant's Earring",
    left_ring="Rahab Ring",
    right_ring="Kishar Ring",
    back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','Mag. Evasion+10','"Fast Cast"+10','Damage taken-5%',}},
	}
  


	--------------------------------------
	-- Midcast sets
	--------------------------------------

    sets.midcast.FastRecast = set_combine(sets.precast.FC,{ammo="Staunch Tathlum",neck="Loricate Torque +1",head="Souveran Schaller +1",legs="Founder's Hose",})		
	sets.midcast.FastRecast.DT = set_combine(sets.precast.FC.DT,{})

    sets.midcast.Flash = {}
	
    sets.midcast.Flash.DT = set_combine(sets.midcast.Flash, {})
	
	sets.midcast['Blue Magic'] = set_combine(sets.Enmity, {})
	
	sets.midcast['Blue Magic'].DT = set_combine(sets.Enmity.DT, {})
    
	sets.midcast.Stun = set_combine(sets.Enmity, {})
	
    sets.midcast.Cure = {ammo="Staunch Tathlum",  --10% SIRD
    head="Souveran Schaller +1",  --20% SIRD
    body="Souveran Cuirass +1",  
    hands="Souveran Handschuhs +1",
    legs="Founder's Hose",  --30% SIRD
    feet="Souveran Schuhs +1",
    neck="Loricate Torque +1",  --2% SIRD
    waist="Gishdubar Sash",
    left_ear="Nourishing Earring +1",  --5% SIRD
    right_ear="Mendicant's Earring",
    left_ring="Menelaus's Ring",
    right_ring="Lebeche Ring",
    back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','Mag. Evasion+10','"Fast Cast"+10','Damage taken-5%',}},}

    sets.midcast.Cure.DT = {}
		
    sets.midcast.Reprisal = {}

	sets.midcast['Crusade'] = set_combine(sets.precast.FC,{})
		
	sets.Self_Healing = {waist="Gishdubar Sash",}
	
	sets.Self_Healing.DT = {}

	sets.Cure_Received = {ammo="Sapience Orb",
    head="Souveran Schaller +1",
    body="Souveran Cuirass +1",
    hands="Souveran Handschuhs +1",
    legs="Souveran Diechlings +1",
    feet="Souveran Schuhs +1",
    neck="Diemer Gorget",
    waist="Gishdubar Sash",
    left_ear="Nourishing Earring +1",
    right_ear="Mendicant's Earring",
    left_ring="Menelaus's Ring",
    right_ring="Lebeche Ring",
    back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','Mag. Evasion+10','"Fast Cast"+10','Damage taken-5%',}},}
	sets.Refresh_Received = {waist="Gishdubar Sash",}
	sets.Cursna_Received = {waist="Gishdubar Sash",ring1="Menelaus's Ring",neck="Nicander's Necklace",ring2="Purity Ring"}
	
	sets.Phalanx_Received = set_combine(sets.midcast.Phalanx,{})

    sets.midcast['Enhancing Magic'] = {waist="Gishdubar Sash",legs="Carmine Cuisses +1"}

	sets.midcast.Stoneskin = set_combine(sets.midcast['Enhancing Magic'], {waist="Siegel Sash"})
    sets.midcast.Protect = set_combine(sets.midcast['Enhancing Magic'], {})
    sets.midcast.Shell = set_combine(sets.midcast['Enhancing Magic'], {})
	
	sets.midcast.Phalanx = {main="Sakpata's Sword",sub="Priwen",hands="Souveran Handschuhs +1",legs="Sakpata's Cuisses",feet="Souveran Schuhs +1"}

    sets.midcast['Enfeebling Magic'] = {}	
	
	sets.midcast['Enfeebling Magic'].DT = set_combine(sets.midcast['Enfeebling Magic'],{})
		

	sets.midcast['Divine Magic'] = set_combine(sets.midcast['Enfeebling Magic'], {})	
	sets.midcast['Divine Magic'].DT = set_combine(sets.midcast['Enfeebling Magic'].DT, {})	
	sets.midcast['Elemental Magic'] = set_combine(sets.midcast['Enfeebling Magic'], {})		
	sets.midcast['Elemental Magic'].DT = set_combine(sets.midcast['Enfeebling Magic'].DT, {})		
	sets.midcast['Dark Magic'] = set_combine(sets.midcast['Enfeebling Magic'], {})	
	sets.midcast['Dark Magic'].DT = set_combine(sets.midcast['Enfeebling Magic'].DT, {})	
	
	--------------------------------------
	-- Idle/resting/defense/etc sets
	--------------------------------------


    -- Idle sets  Normal is max HP
    sets.idle = {
	ammo="Staunch Tathlum",
    head={ name="Souv. Schaller +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
    body={ name="Cab. Surcoat +3", augments={'Enhances "Fealty" effect',}},
    hands={ name="Souv. Handsch. +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
    legs={ name="Souv. Diechlings +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
    feet={ name="Souveran Schuhs +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
    neck={ name="Loricate Torque +1", augments={'Path: A',}},
    waist="Flume Belt +1",
    left_ear="Odnowa Earring +1",
    right_ear="Tuisto Earring",
    left_ring="Moonbeam Ring",
    right_ring="Warp Ring",
    back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','Mag. Evasion+10','"Fast Cast"+10','Damage taken-5%',}},
	}
		
	sets.idle.idle2 = set_combine(sets.idle,{})
	sets.idle.DD = {ammo="Ginsen",
    head="Flam. Zucchetto +2",
    body="Flamma Korazin +2",
    hands="Sulev. Gauntlets +2",
    legs="Sulev. Cuisses +2",
    feet="Flam. Gambieras +2",
    neck="Lissome Necklace",
    waist={ name="Sailfi Belt +1", augments={'Path: A',}},
    left_ear="Cessance Earring",
    right_ear="Brutal Earring",
    left_ring="Petrov Ring",
    right_ring="Flamma Ring",
    back="Atheling Mantle",}
	
    sets.resting = set_combine(sets.idle,{})

	sets.idle.PDT = set_combine(sets.defense.PDT,{})		
    sets.idle.MDT = set_combine(sets.defense.MDT,{})
	
	
	sets.idle.iFresh = set_combine(sets.idle,{})

    sets.idle.Reraise = set_combine(sets.idle.PDT,{head="Twilight Helm",body="Twilight Mail"})
		
    sets.idle.Weak = set_combine(sets.idle.PDT,{})
		
	sets.Kiting = {ammo="Staunch Tathlum",
    head={ name="Souv. Schaller +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
    body={ name="Cab. Surcoat +3", augments={'Enhances "Fealty" effect',}},
    hands={ name="Souv. Handsch. +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
    legs={ name="Carmine Cuisses +1", augments={'Accuracy+20','Attack+12','"Dual Wield"+6',}},
    feet={ name="Souveran Schuhs +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
    neck={ name="Loricate Torque +1", augments={'Path: A',}},
    waist="Flume Belt +1",
    left_ear="Odnowa Earring +1",
    right_ear="Tuisto Earring",
    left_ring="Moonbeam Ring",
    right_ring="Moonbeam Ring",
    back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','Mag. Evasion+10','"Fast Cast"+10','Damage taken-5%',}},
}

	sets.latent_refresh = {}
	sets.latent_regen = {}
	sets.DayIdle = {}
	sets.NightIdle = {}

	--------------------------------------
    -- Defense sets
    --------------------------------------
    
    -- Extra defense sets.  Apply these on top of melee or defense sets.
	sets.TreasureHunter = set_combine(sets.TreasureHunter, {Ammo="Perfect Lucky Egg",feet="Volte Boots",belt="Chaac Belt",head="Wh. Rarab Cap +1"})
	sets.Knockback = {}
    sets.MP = {}
    sets.MP_Knockback = {}
    sets.Twilight = {head="Twilight Helm", body="Twilight Mail"}
    
    -- If EquipShield toggle is on (Win+F10 or Win+F11), equip the weapon/shield combos here
    -- when activating or changing defense mode:
    sets.PhysicalShield = {main="Burtgang",sub="Priwen"}
    sets.MagicalShield = {sub="Aegis"}
	
    sets.defense.PDT = {sub="Priwen",
	ammo="Staunch Tathlum",		--2%DT
    head="Sakpata's Helm",		--7%DT
    body="Sakpata's Plate",		--10%DT
    hands="Sakpata's Gauntlets",	--8%DT
    legs="Sakpata's Cuisses",		--9%DT
    feet="Sakpata's Leggings",		--6%dt
    neck={ name="Loricate Torque +1", augments={'Path: A',}},	--6%DT
    waist="Chuq'aba Belt",
    left_ear="Odnowa Earring +1",
    right_ear="Thureous Earring",
    left_ring="Moonbeam Ring",
    right_ring="Moonbeam Ring",
    back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','Mag. Evasion+10','"Fast Cast"+10','Damage taken-5%',}},
}
	
    sets.defense.PDT_HP = set_combine(sets.defense.PDT,{
	})
	
	sets.defense.MDT = { main="Burtgang",
    sub="Aegis",
    ammo="Staunch Tathlum",		--2%DT
    head="Sakpata's Helm",		--7%DT
    body="Sakpata's Plate",		--10%DT
    hands="Sakpata's Gauntlets",	--8%DT
    legs="Sakpata's Cuisses",		--9%DT
    feet="Sakpata's Leggings",		--6%dt
    neck={ name="Loricate Torque +1", augments={'Path: A',}},	--6%DT
    waist="Chuq'aba Belt",
    left_ear="Odnowa Earring +1",
    right_ear="Thureous Earring",
    left_ring="Moonbeam Ring",
    right_ring="Moonbeam Ring",
    back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','Mag. Evasion+10','"Fast Cast"+10','Damage taken-5%',}},
}
	
    sets.defense.MDT_HP = set_combine(sets.defense.PDT_HP,{
		main="Burtgang",
		sub="Aegis",})		
	sets.defense.MEVA = set_combine(sets.defense.MDT,{})
	sets.defense.MEVA_HP = set_combine(sets.defense.PDT_HP,{})
	
	

	--------------------------------------
	-- Engaged sets
	--------------------------------------
    
	sets.engaged = {
	main="Burtgang",
	sub="Priwen",
	ammo="Amar Cluster",
    head="Sakpata's Helm",  --7%DT
    body="Sakpata's Plate",  --10%DT
    hands="Sakpata's Gauntlets",  --8%DT
    legs="Sakpata's Cuisses",  --9%DT
    feet="Sakpata's Leggings",  --6%DT
    neck="Lissome Necklace",
    waist="Sailfi Belt +1",
    left_ear="Odnowa Earring +1",
    right_ear="Thureous Earring",
    left_ring="Moonbeam Ring",  --4%DT
    right_ring="Moonbeam Ring",  --4%DT
    back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','Mag. Evasion+10','"Fast Cast"+10','Damage taken-5%',}},
}

    sets.engaged.DD = {
	main="Naegling",
	sub="Blurred Shield +1",
	ammo="Amar Cluster",
    head="Sakpata's Helm",  --7%DT
    body="Sakpata's Plate",  --10%DT
    hands="Sakpata's Gauntlets",  --8%DT
    legs="Sakpata's Cuisses",  --9%DT
    feet="Sakpata's Leggings",  --6%DT
    neck="Lissome Necklace",
    waist="Sailfi Belt +1",
    left_ear="Cessance Earring",
    right_ear="Thureous Earring",
    left_ring="Moonbeam Ring",  --4%DT
    right_ring="Moonbeam Ring",  --4%DT
    back="Atheling Mantle",
	}

    sets.engaged.Aegis = {
	main="Burtgang",
	sub="Aegis",
	ammo="Amar Cluster",
    head="Sakpata's Helm",  --7%DT
    body="Sakpata's Plate",  --10%DT
    hands="Sakpata's Gauntlets",  --8%DT
    legs="Sakpata's Cuisses",  --9%DT
    feet="Sakpata's Leggings",  --6%DT
    neck="Lissome Necklace",
    waist="Sailfi Belt +1",
    left_ear="Odnowa Earring +1",
    right_ear="Thureous Earring",
    left_ring="Moonbeam Ring",  --4% DT
    right_ring="Moonbeam Ring",  --4% DT
    back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','Mag. Evasion+10','"Fast Cast"+10','Damage taken-5%',}},
	}
	
		
    -- Weaponskill sets
    -- Default set for any weaponskill that isn't any more specifically defined
   sets.precast.WS = {
	ammo="Oshasha's Treatise",
    head="Odyssean Helm",
    body="Odyssean Chestplate",
    hands="Odyssean Gauntlets",
    legs="Odyssean Cuisses",
    feet="Sulev. Leggings +2",
    neck="Fotia Gorget",
    waist="Fotia Belt",
    left_ear="Moonshade Earring",
    right_ear="Thrud Earring",
    left_ring="Cornelia's Ring",
    right_ring="Epaminondas's Ring",
    back="Atheling Mantle",}
		
    sets.precast.WS.DT = {
	ammo="Staunch Tathlum",
	head={ name="Cab. Coronet +3", augments={'Enhances "Iron Will" effect',}},
    body={ name="Cab. Surcoat +3", augments={'Enhances "Fealty" effect',}},
    hands={ name="Cab. Gauntlets +3", augments={'Enhances "Chivalry" effect',}},
    legs={ name="Cab. Breeches +3", augments={'Enhances "Invincible" effect',}},
    feet={ name="Cab. Leggings +3", augments={'Enhances "Guardian" effect',}},
	neck="Fotia Gorget",
	waist="Fotia Belt",
	left_ear={ name="Moonshade Earring", augments={'Accuracy+4','TP Bonus +250',}},
    right_ear="Brutal Earring",
    left_ring="Flamma Ring",
    right_ring="Rajas Ring",
	back="Atheling Mantle",}

    sets.precast.WS.Acc = {ammo="Hasty Pinion +1",
        head="Ynglinga Sallet",neck="Combatant's Torque",ear1="Mache Earring +1",ear2="Telos Earring",
        body=gear.valorous_wsd_body,hands="Sakpata's Gauntlets",ring1="Ramuh Ring +1",ring2="Ramuh Ring +1",
        back="Ground. Mantle +1",waist="Olseni Belt",legs="Carmine Cuisses +1",feet="Sulev. Leggings +2"}

    -- Specific weaponskill sets.  Uses the base set if an appropriate WSMod version isn't found.
    sets.precast.WS['Requiescat'] = set_combine(sets.precast.WS, {neck="Fotia Gorget",ear1="Brutal Earring",ear2="Moonshade Earring"})
    sets.precast.WS['Requiescat'].Acc = set_combine(sets.precast.WS.Acc, {neck="Fotia Gorget",ear1="Mache Earring +1",ear2="Moonshade Earring"})

	sets.precast.WS['Chant du Cygne'] = set_combine(sets.precast.WS, {neck="Fotia Gorget",ear1="Brutal Earring",ear2="Moonshade Earring"})
    sets.precast.WS['Chant du Cygne'].Acc = set_combine(sets.precast.WS.Acc, {neck="Fotia Gorget",ear1="Mache Earring +1",ear2="Moonshade Earring"})

	sets.precast.WS['Savage Blade'] = set_combine(sets.precast.WS, {})
    sets.precast.WS['Savage Blade'].Acc = set_combine(sets.precast.WS.Acc, {ear1="Mache Earring +1",ear2="Telos Earring"})
	
	sets.precast.WS['Flat Blade'] = {ammo="Aurgelmir Orb +1",
        head="Flam. Zucchetto +2",neck="Erra Pendant",ear1="Gwati Earring",ear2="Digni. Earring",
        body="Flamma Korazin +2",hands="Flam. Manopolas +2",ring1="Defending Ring",ring2="Stikini Ring +1",
        back="Ground. Mantle +1",waist="Olseni Belt",legs="Flamma Dirs +2",feet="Flam. Gambieras +2"}

    sets.precast.WS['Sanguine Blade'] = {ammo="Ghastly Tathlum +1",
        head="Pixie Hairpin +1",neck="Fotia Gorget",ear1="Friomisi Earring",ear2="Crematio Earring",
        body="Nyame Mail",hands="Nyame Gauntlets",ring1="Archon Ring",ring2="Metamor. Ring +1",
        back="Toro Cape",waist="Fotia Belt",legs="Nyame Flanchard",feet="Nyame Sollerets"}

    sets.precast.WS['Atonement'] = {ammo="Sapience Orb",
        head="Caballarius Coronet +3",neck="Knight's Bead Necklace +1",ear1="Friomisi Earring",ear2="Trux Earring",
        body="Souv. Cuirass +1",hands="Caballarius Gauntlets +3",ring1="Eihwaz Ring",ring2="Petrov Ring",
        back="Rudianos's Mantle",waist="Creed Baudrier",legs="Caballarius Breeches +2",feet="Souveran Schuhs +1"}

	-- Swap to these on Moonshade using WS if at 3000 TP
	sets.MaxTP = {ear1="Cessance Earring",ear2="Brutal Earring",}
	sets.AccMaxTP = {ear1="Mache Earring +1",ear2="Telos Earring"}


		--------------------------------------
	-- Custom buff sets
	--------------------------------------
	sets.buff.Doom = set_combine(sets.buff.Doom, {ring1="Eshmun's Ring",ring2="Eshmun's Ring"})
	sets.buff.Sleep = {}
    sets.buff.Cover = {body="Cab. Surcoat +3"}
end

-- Select default macro book on initial load or subjob change.
function select_default_macro_book()
	-- Default macro set/book
	if player.sub_job == 'WAR' then
		set_macro_page(1, 1)
	elseif player.sub_job == 'NIN' then
		set_macro_page(2, 1)
	elseif player.sub_job == 'RUN' then
		set_macro_page(3, 1)
	elseif player.sub_job == 'THF' then
		set_macro_page(1, 7)
	elseif player.sub_job == 'RDM' then
		set_macro_page(4, 1)
	else
		set_macro_page(1, 1)
	end
end

function set_lockstyle()
    send_command('wait 6; input /lockstyleset 14')
end

function check_flash()
	local spell_recasts = windower.ffxi.get_spell_recasts()

	if not buffactive['Enmity Boost'] and spell_recasts[476] < spell_latency then
		windower.chat.input('/ma "Crusade" <me>')
		tickdelay = (framerate * 2)
		return true
	elseif spell_recasts[112] < spell_latency then
		send_command('input /ma "Flash" <t>')
		tickdelay = (framerate * 2)
		return true
	else
		return false
	end
end
