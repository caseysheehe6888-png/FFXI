-- Setup vars that are user-dependent.  Can override this function in a sidecar.
function user_setup()
    state.OffenseMode:options('Normal','Acc')
    state.CastingMode:options('Normal','Resistant')
    state.IdleMode:options('Normal', 'iFresh','iRegen', 'PDT')
	state.Weapons:options('None','Nirvana')

    gear.perp_staff = {name="Nirvana"}
	
	
	
--    send_command('bind !` input /ja "Release" <me>')
--	send_command('bind @` gs c cycle MagicBurst')
	send_command('bind ` gs c toggle PactSpamMode')
--	send_command('bind !pause gs c toggle AutoSubMode') --Automatically uses sublimation.
--	send_command('bind ^q gs c weapons Khatvanga;gs c set CastingMode OccultAcumen')
--	send_command('bind !q gs c weapons default;gs c reset CastingMode')
	send_command('bind ^` gs c cycle Weapons')		
    select_default_macro_book()
    set_lockstyle()		
end

-- Define sets and vars used by this job file.
function init_gear_sets()

	-- Weapons sets
	sets.weapons.Nirvana = {main="Nirvana", sub="Elan Strap +1"}	
	
    --------------------------------------
    -- Precast Sets
    --------------------------------------
    
	sets.TreasureHunter = set_combine(sets.engaged, {head="Wh. Rarab Cap +1", waist="Chaac Belt"})
	
    -- Precast sets to enhance JAs
    sets.precast.JA['Astral Flow'] = {head="Glyphic Horn +3"}
    
	sets.precast.JA['Elemental Siphon'] = {
		ammo="Esper Stone +1",
		head="Baayami Hat +1",
		body="Baayami Robe",
		hands="Baayami Cuffs",
		legs="Baayami Slops",
		feet="Beck. Pigaches +1",
		neck="Incanter's Torque",
		waist="Cimmerian Sash",
		left_ear="Gifted Earring",
		right_ear="Andoaa Earring", --Lodurr Earring
		left_ring="Evoker's Ring",
		right_ring="Zodiac Ring",
		back="Conveyance Cape",
	}
    
	sets.precast.JA['Mana Cede'] = {hands="Beckoner's Bracers +1"}
	sets.precast.JA['Avatar\'s Favor'] = set_combine(sets.midcast.Pet.BloodPactWard, {head="Beckoner's Horn +1"})

    -- Pact delay reduction gear
    sets.precast.BloodPactRage = set_combine(sets.midcast.Pet.BloodPactWard,{
		ammo="Sancus Sachet +1",
		head="Beckoner's Horn +1",
		body="Baayami Robe",
		hands="Baayami Cuffs",
		legs="Baayami Slops",
		feet="Beck. Pigaches +1",
		neck="Incanter's Torque",
		waist="Cimmerian Sash",
		left_ear="Gifted Earring",
		right_ear="Andoaa Earring", --Lodurr Earring
		left_ring="Evoker's Ring",
		ring2={ name="Stikini Ring +1", bag="wardrobe4"},
		back="Conveyance Cape",
	})

	sets.precast.BloodPactWard = sets.precast.BloodPactRage


    -- Fast cast sets for spells
    
    sets.precast.FC = {
		head="Nahtirah Hat",
		body="Baayami Robe",
		hands={ name="Merlinic Dastanas", augments={'"Mag.Atk.Bns."+12','"Fast Cast"+5','INT+4','Mag. Acc.+10',}},
		legs="Assid. Pants +1",
		feet="Regal Pumps +1",
		neck="Voltsurge Torque",
		waist="Witful Belt", --Embla Sash
		left_ear="Loquac. Earring",
		right_ear="Etiolation Earring",
		left_ring="Kishar Ring",
		right_ring="Prolix Ring",
		back={ name="Campestres's Cape", augments={'Pet: M.Acc.+20 Pet: M.Dmg.+20','Pet: Magic Damage+10','Pet: "Regen"+10','Pet: "Regen"+5',}},
    }

    sets.precast.FC['Enhancing Magic'] = set_combine(sets.precast.FC, {
		waist="Siegel Sash",
        back="Perimede Cape"	
	})
    
	sets.precast.FC.Stoneskin = set_combine(sets.precast.FC['Enhancing Magic'], {head="Umuthi Hat", hands="Carapacho Cuffs"})
    
	sets.precast.FC['Elemental Magic'] = set_combine(sets.precast.FC, {})
    
	sets.precast.FC.Cure = set_combine(sets.precast.FC, {
		head="Vanya Hood",
		body={ name="Vanya Robe", augments={'Healing magic skill +20','"Cure" spellcasting time -7%','Magic dmg. taken -3',}},
		hands={ name="Vanya Cuffs", augments={'Healing magic skill +20','"Cure" spellcasting time -7%','Magic dmg. taken -3',}},
		legs="Vanya Slops",
		feet={ name="Vanya Clogs", augments={'"Cure" potency +5%','"Cure" spellcasting time -15%','"Conserve MP"+6',}},
		ear2="Mendi. Earring",
		back="Pahtli Cape",
    })
    
	

    --------------------------------------
    -- Midcast sets
    --------------------------------------

    sets.midcast.FastRecast = set_combine(sets.precast.FC,{})
	
    sets.midcast.Cure = {
		head="Vanya Hood",
		body={ name="Vanya Robe", augments={'Healing magic skill +20','"Cure" spellcasting time -7%','Magic dmg. taken -3',}},
		hands={ name="Vanya Cuffs", augments={'Healing magic skill +20','"Cure" spellcasting time -7%','Magic dmg. taken -3',}},
		legs={ name="Vanya Slops", augments={'Healing magic skill +20','"Cure" spellcasting time -7%','Magic dmg. taken -3',}},
		feet={ name="Vanya Clogs", augments={'"Cure" potency +5%','"Cure" spellcasting time -15%','"Conserve MP"+6',}},
		neck="Incanter's Torque",
		waist="Bishop's Sash",
		left_ear="Beatific Earring",
		right_ear="Mendi. Earring",
		left_ring="Sirona's Ring",
		ring2={ name="Stikini Ring +1", bag="wardrobe4"},
		back="Pahtli Cape",
    }
 
		
	sets.Self_Healing = {}
	sets.Cure_Received = {}
	sets.Self_Refresh = {head="Amalric Coif +1", waist="Gishdubar Sash"}
	sets.midcast.Cursna =  set_combine(sets.midcast.Cure, {})
	sets.midcast.StatusRemoval = set_combine(sets.midcast.FastRecast, {})

	sets.midcast['Elemental Magic'] = {
		head={ name="Merlinic Hood", augments={'Mag. Acc.+24 "Mag.Atk.Bns."+24','INT+5','Mag. Acc.+8','"Mag.Atk.Bns."+13',}},
        body="Amalric Doublet +1",
        hands="Amalric Gages +1",
        legs="Amalric Slops +1",
		feet="Amalric Nails +1",
		neck="Sanctity Necklace",
		waist="Sacro Cord",
		ear1="Regal Earring",
		ear2="Friomisi Earring",
		left_ring="Shiva Ring +1",
		right_ring="Shiva Ring +1",
		back={ name="Campestres's Cape", augments={'Pet: M.Acc.+20 Pet: M.Dmg.+20','Pet: Magic Damage+10','Pet: "Regen"+10','Pet: "Regen"+5',}}, 
	}
	sets.midcast['Elemental Magic'].Resistant = set_combine(sets.midcast['Elemental Magic'],{})
    sets.midcast['Elemental Magic'].OccultAcumen = set_combine(sets.midcast['Elemental Magic'],{})
	sets.midcast.Impact = set_combine(sets.midcast['Elemental Magic'],{})
	sets.midcast.Impact.OccultAcumen = set_combine(sets.midcast['Elemental Magic'],{})
    sets.midcast['Divine Magic'] = set_combine(sets.midcast['Elemental Magic'],{})
	
    sets.midcast['Dark Magic'] = set_combine(sets.midcast['Elemental Magic'],{})
	sets.midcast.Drain = set_combine(sets.midcast['Dark Magic'],{head="Pixie hairpin +1"})
    sets.midcast.Aspir = set_combine(sets.midcast['Dark Magic'],{head="Pixie hairpin +1"})
	sets.midcast.Stun = set_combine(sets.midcast['Dark Magic'],{})
    sets.midcast.Stun.Resistant = set_combine(sets.midcast['Dark Magic'],{})
		
	sets.midcast['Enfeebling Magic'] = set_combine(sets.midcast['Elemental Magic'],{})
	sets.midcast['Enfeebling Magic'].Resistant = set_combine(sets.midcast['Enfeebling Magic'],{})
		
	sets.midcast.Dia = set_combine(sets.midcast['Enfeebling Magic'], {})
	sets.midcast.Diaga = set_combine(sets.midcast['Enfeebling Magic'], {})
	sets.midcast['Dia II'] = set_combine(sets.midcast['Enfeebling Magic'], {})
	sets.midcast.Bio = set_combine(sets.midcast['Enfeebling Magic'], {})
	sets.midcast['Bio II'] = set_combine(sets.midcast['Enfeebling Magic'], {})
		
	sets.midcast['Enhancing Magic'] = {
		head="Telchine Cap",
        body="Telchine Chas.",
        hands="Telchine Gloves",
        legs="Telchine Braconi",
        feet="Telchine Pigaches",
		neck="Incanter's Torque",
		waist="Siegel Sash", --Embla Sash
		ear1="Loquac. Earring",
		ear2="Andoaa Earring", --Mimir Earring
		ring1={ name="Stikini Ring +1", bag="wardrobe"},
		ring2={ name="Stikini Ring +1", bag="wardrobe4"},
		back="Perimede Cape",		
	}
		
	sets.midcast.Refresh = set_combine(sets.midcast['Enhancing Magic'], {head="Amalric Coif +1"})
	
	sets.midcast.Aquaveil = set_combine(sets.midcast['Enhancing Magic'], {head="Amalric Coif +1"})
    
	sets.midcast.Stoneskin = set_combine(sets.midcast['Enhancing Magic'], {neck="Nodens Gorget",ear2="Earthcry Earring",legs="Haven Hose",waist="Siegel Sash"})
	
	sets.midcast.BarElement = set_combine(sets.precast.FC['Enhancing Magic'], {})

    -- Avatar pact sets.  All pacts are Ability type.
    
    sets.midcast.Pet.BloodPactWard = {
		main="Nirvana",
		sub="Elan Strap +1",
		ammo="Sancus Sachet +1",
		head="Baayami Hat +1",
		body="Baayami Robe",
		hands="Baayami Cuffs",
		legs="Baayami Slops",
		feet="Baaya. Sabots +1",
		neck="Incanter's Torque",
		waist="Cimmerian Sash",
		left_ear="Gifted Earring",
		right_ear="Andoaa Earring", --Lodurr Earring
		left_ring="Evoker's Ring",
		ring2={ name="Stikini Ring +1", bag="wardrobe4"},
		back="Conveyance Cape",
	}

    sets.midcast.Pet.DebuffBloodPactWard = set_combine(sets.midcast.Pet.BloodPactWard,{
		head="Beckoner's Horn +1",
		body="Con. Doublet +3",
		hands="Lamassu Mitts +1",
		legs="Tali'ah Sera. +2",
		feet="Beck. Pigaches +1",
		neck="Shulmanu Collar",
		waist="Incarnation Sash",
		left_ear="Gifted Earring",
		right_ear="Lugalbanda Earring",
		left_ring="Evoker's Ring",
		right_ring="Stikini Ring +1",
		back={ name="Campestres's Cape", augments={'Pet: M.Acc.+20 Pet: M.Dmg.+20','Pet: Magic Damage+10','Pet: "Regen"+10','Pet: "Regen"+5',}},
	})
    
	sets.midcast.Pet.DebuffBloodPactWard.Acc = set_combine(sets.midcast.Pet.DebuffBloodPactWard,{})
    
    sets.midcast.Pet.PhysicalBloodPactRage = {
		main="Nirvana",
		sub="Elan Strap +1",
		ammo="Sancus Sachet +1",
		head="Helios Band",
		body="Con. Doublet +3",
		hands={ name="Merlinic Dastanas", augments={'Pet: "Mag.Atk.Bns."+8','Blood Pact Dmg.+9','Pet: STR+8','Pet: Mag. Acc.+3',}},
		legs={ name="Apogee Slacks +1", augments={'Pet: STR+20','Blood Pact Dmg.+14','Pet: "Dbl. Atk."+4',}},
		feet="Helios Boots",
		neck="Shulmanu Collar",
		waist="Incarnation Sash",
		left_ear="Gelos Earring",
		right_ear="Lugalbanda Earring",
		ring1={ name="Varar Ring", bag="wardrobe3"},
		ring2={ name="Varar Ring", bag="wardrobe4"},
		back={ name="Campestres's Cape", augments={'Pet: Acc.+20 Pet: R.Acc.+20 Pet: Atk.+20 Pet: R.Atk.+20','Pet: Attack+10 Pet: Rng.Atk.+10',}},	
	}
		
    sets.midcast.Pet.PhysicalBloodPactRage.Acc = {feet="Convo. Pigaches +3"}

    sets.midcast.Pet.MagicalBloodPactRage = {
		--main={ name="Grioavolr", augments={'Blood Pact Dmg.+10','Pet: Mag. Acc.+25','Pet: "Mag.Atk.Bns."+14','DMG:+10',}},
		sub="Elan Strap +1",
		ammo="Sancus Sachet +1",
		head="Apogee Crown +1",
		body="Con. Doublet +3",
		hands={ name="Merlinic Dastanas", augments={'Blood Pact Dmg.+9','Pet: Mag. Acc.+15','Pet: "Mag.Atk.Bns."+12',}},
		legs="Enticer's Pants",
		feet={ name="Apogee Pumps +1", augments={'MP+80','Pet: "Mag.Atk.Bns."+35','Blood Pact Dmg.+8',}},
		neck="Shulmanu Collar",
		waist="Regal Belt",
		left_ear="Gelos Earring",
		right_ear="Lugalbanda Earring",
		ring1={ name="Varar Ring", bag="wardrobe3"},
		ring2={ name="Varar Ring", bag="wardrobe4"},
		back={ name="Campestres's Cape", augments={'Pet: M.Acc.+20 Pet: M.Dmg.+20','Pet: Magic Damage+10','Pet: "Regen"+10','Pet: "Regen"+5',}},	
	}

    sets.midcast.Pet.MagicalBloodPactRage.Acc = set_combine(sets.midcast.Pet.MagicalBloodPactRage,{feet="Convoker's pigaches +2"})


	sets.midcast.Pet['Flaming Crush'] = set_combine(sets.midcast.Pet.MagicalBloodPactRage,{
		main="Nirvana",
		sub="Elan Strap +1",
		ammo="Sancus Sachet +1",
		head="Apogee Crown +1",
		body="Con. Doublet +3",
		hands={ name="Merlinic Dastanas", augments={'Blood Pact Dmg.+9','Pet: Mag. Acc.+15','Pet: "Mag.Atk.Bns."+12',}},
		legs="Enticer's Pants",
		feet={ name="Apogee Pumps +1", augments={'MP+80','Pet: "Mag.Atk.Bns."+35','Blood Pact Dmg.+8',}},
		neck="Shulmanu Collar",
		waist="Regal Belt",
		left_ear="Gelos Earring",
		right_ear="Lugalbanda Earring",
		ring1={ name="Varar Ring", bag="wardrobe3"},
		ring2={ name="Varar Ring", bag="wardrobe4"},
	})
	
	sets.midcast.Pet['Predator Claws'] = set_combine(sets.midcast.Pet.PhysicalBloodPactRage,{
		head="Helios Band",
		body="Con. Doublet +3",
		hands={ name="Merlinic Dastanas", augments={'Pet: "Mag.Atk.Bns."+8','Blood Pact Dmg.+9','Pet: STR+8','Pet: Mag. Acc.+3',}},
		legs={ name="Apogee Slacks +1", augments={'Pet: STR+20','Blood Pact Dmg.+14','Pet: "Dbl. Atk."+4',}},
		feet="Helios Boots",
		neck="Shulmanu Collar",
		waist="Incarnation Sash",
		left_ear="Gelos Earring",
		right_ear="Lugalbanda Earring",
		ring1={ name="Varar Ring", bag="wardrobe3"},
		ring2={ name="Varar Ring", bag="wardrobe4"},
		back={ name="Campestres's Cape", augments={'Pet: Acc.+20 Pet: R.Acc.+20 Pet: Atk.+20 Pet: R.Atk.+20','Pet: Attack+10 Pet: Rng.Atk.+10',}},
	})
		
	sets.midcast.Pet['Flaming Crush'].Acc = set_combine(sets.midcast.Pet['Flaming Crush'],{feet="Convo. Pigaches +2"})

	
    -- Spirits cast magic spells, which can be identified in standard ways.
    
    sets.midcast.Pet.WhiteMagic = {} --legs="Summoner's Spats"
    sets.midcast.Pet['Elemental Magic'] = set_combine(sets.midcast.Pet.MagicalBloodPactRage, {}) --legs="Summoner's Spats"
    sets.midcast.Pet['Elemental Magic'].Resistant = set_combine(sets.midcast.Pet['Elemental Magic'],{})
    
	
	sets.midcast.Pet['Mountain Buster'] = set_combine(sets.midcast.Pet.PhysicalBloodPactRage, {legs="Enticer's Pants"})
	sets.midcast.Pet['Mountain Buster'].Acc = set_combine(sets.midcast.Pet.PhysicalBloodPactRage.Acc, {legs="Enticer's Pants"})
	sets.midcast.Pet['Rock Buster'] = set_combine(sets.midcast.Pet.PhysicalBloodPactRage, {legs="Enticer's Pants"})
	sets.midcast.Pet['Rock Buster'].Acc = set_combine(sets.midcast.Pet.PhysicalBloodPactRage.Acc, {legs="Enticer's Pants"})
	sets.midcast.Pet['Crescent Fang'] = set_combine(sets.midcast.Pet.PhysicalBloodPactRage, {legs="Enticer's Pants"})
	sets.midcast.Pet['Crescent Fang'].Acc = set_combine(sets.midcast.Pet.PhysicalBloodPactRage.Acc, {legs="Enticer's Pants"})
	sets.midcast.Pet['Eclipse Bite'] = set_combine(sets.midcast.Pet.PhysicalBloodPactRage, {legs="Enticer's Pants"})
	sets.midcast.Pet['Eclipse Bite'].Acc = set_combine(sets.midcast.Pet.PhysicalBloodPactRage.Acc, {legs="Enticer's Pants"})
	sets.midcast.Pet['Blindside'] = set_combine(sets.midcast.Pet.PhysicalBloodPactRage, {legs="Enticer's Pants"})
	sets.midcast.Pet['Blindside'].Acc = set_combine(sets.midcast.Pet.PhysicalBloodPactRage.Acc, {legs="Enticer's Pants"})

    --------------------------------------
    -- Idle/resting/defense/etc sets
    --------------------------------------
    
    -- Resting sets
    sets.resting = set_combine(sets.idle,{})
    
    -- Idle sets
    sets.idle = {
		ammo="Sancus Sachet +1",
		head="Beckoner's Horn +1",
		hands="Asteria Mitts +1",
		body="Apogee Dalmatica +1",
		legs="Assid. Pants +1",
		feet="Baayami Sabots",
		neck="Shulmanu Collar",
		waist="Fucho-no-Obi",
		ear1="Gelos Earring",
		ear2="Lugalbanda Earring",
		ring1={ name="Stikini Ring +1", bag="wardrobe"},
		ring2={ name="Stikini Ring +1", bag="wardrobe4"},
		back={ name="Campestres's Cape", augments={'Pet: M.Acc.+20 Pet: M.Dmg.+20','Pet: Magic Damage+10','Pet: "Regen"+10','Pet: "Regen"+5',}}, 
	}
    sets.idle.iFresh = set_combine(sets.idle,{})
    sets.idle.iRegen = set_combine(sets.idle,{
		head="Baayami Hat +1",
		hands="Baayami Cuffs",
		legs="Baayami Slops",
		feet="Baayami Sabots",	
	})
    sets.idle.PDT = set_combine(sets.idle,{
		head="Volte cap",
		body="Mallquis Saio +2",
		hands="Volte Bracers",
		neck="Loricate Torque +1",
		ear1="Genmei earring",
		ear2="Etiolation Earring",
		ring1="Defending Ring",
		ring2="Gelatinous Ring +1",
--		back="Moonlight Cape"	
	})	
	
    
    -- Max useful -perp gear is 1 less than the perp cost (can't be reduced below 1)
    -- Aim for -14 perp, and refresh in other slots.
      
    -- Can make due without either the head or the body, and use +refresh items in those slots.
    
    sets.idle.Avatar = set_combine(sets.idle,{
		neck="Caller's Pendant",	
	})
	
    sets.idle.PDT.Avatar = set_combine(sets.idle.PDT,{})
    sets.idle.Spirit = set_combine(sets.idle,{})
    sets.idle.PDT.Spirit = set_combine(sets.idle.PDT,{})
		
	--Favor always up and head is best in slot idle so no specific items here at the moment.
    sets.idle.Avatar.Favor = {}
    
	sets.idle.Avatar.Engaged = set_combine(sets.idle,{
		head="Baayami Hat +1",
		hands="Baayami Cuffs",
		legs="Baayami Slops",
		feet="Baayami Sabots",	
		
	})
	
	sets.idle.Avatar.Engaged.Carbuncle = {}
	sets.idle.Avatar.Engaged['Cait Sith'] = {}
        
    sets.perp = set_combine(sets.idle,{})
    -- Caller's Bracer's halve the perp cost after other costs are accounted for.
    -- Using -10 (Gridavor, ring, Conv.feet), standard avatars would then cost 5, halved to 2.
    -- We can then use Hagondes Coat and end up with the same net MP cost, but significantly better defense.
    -- Weather is the same, but we can also use the latent on the pendant to negate the last point lost.
    sets.perp.Day = set_combine(sets.perp,{})
    sets.perp.Weather = set_combine(sets.perp,{})
    sets.Town = set_combine(sets.idle,{feet="Herald's Gaiters"})	
--	sets.perp.Carbuncle = set_combine(sets.perp,{})
 --   sets.perp.Diabolos = set_combine(sets.perp,{})
    sets.perp.Alexander = sets.midcast.Pet.BloodPactWard

	-- Not really used anymore, was for the days of specific staves for specific avatars.
--    sets.perp.staff_and_grip = {}
    
    -- Defense sets
    sets.defense.PDT = set_combine(sets.idle.PDT,{})
    sets.defense.MDT = set_combine(sets.idle.PDT,{
		head="Volte Cap",
		hands="Volte Bracers",
		ear1="Odnowa Earring +1",
		
	})
    sets.defense.MEVA = set_combine(sets.idle.PDT,{
		head="Volte Cap",
		hands="Volte Bracers"
	})		
    sets.Kiting = {feet="Herald's Gaiters"}
    sets.latent_refresh = {}
	sets.DayIdle = {}
	sets.NightIdle = {}

	sets.HPDown = set_combine(sets.idle,{})
	sets.buff.Doom = set_combine(sets.buff.Doom, {})
	sets.buff.Sleep = {}

    --------------------------------------
    -- Engaged sets
    --------------------------------------
    
    -- Normal melee group
    sets.engaged = {
		ammo="Sancus Sachet +1",
		head="Glyphic Horn +3",
		body="Glyphic doublet +3",
		hands="Glyphic bracers +3",
		legs="Glyphic spats +3",
		feet="Glyphic Pigaches +3",
		neck="Sanctity Necklace",
		waist="Windbuffet Belt +1",
		ear1="Mache Earring +1",
		ear2="Mache Earring +1",
		ring1={ name="Chirich Ring +1", bag="wardrobe"},
		ring2={ name="Chirich Ring +1", bag="wardrobe2"},
		back={ name="Campestres's Cape", augments={'Pet: Acc.+20 Pet: R.Acc.+20 Pet: Atk.+20 Pet: R.Atk.+20','Pet: Attack+10 Pet: Rng.Atk.+10',}}, 	
	}
	sets.engaged.Acc = set_combine(sets.engaged,{
		body="Convoker's doublet +3",
		waist="Eschan stone",
		})
	   
	   
    -- Weaponskill sets
    -- Default set for any weaponskill that isn't any more specifically defined
    
	sets.precast.WS = set_combine(sets.engaged,{neck="Fotia Gorget",waist="Fotia Belt"})
    
	sets.precast.WS.Acc = set_combine(sets.engaged.Acc,{neck="Fotia Gorget",waist="Fotia Belt"})
    
	-- Specific weaponskill sets.  Uses the base set if an appropriate WSMod version isn't found.
    
	sets.precast.WS['Myrkr'] = set_combine(sets.idle,{neck="Fotia Gorget",waist="Fotia Belt"})
    
	sets.precast.WS['Garland of Bliss'] = set_combine(sets.WS,{
        head="Amalric Coif +1",
        body="Amalric Doublet +1",
        hands="Amalric Gages +1",
        legs="Amalric Slops +1",
		feet="Amalric Nails +1",
		neck="Sanctity Necklace",
		waist="Fotia Belt", --Orpheous's Sash
		ear1="Friomisi Earring",
		ear2="Ishvara Earring",
		ring1="Shiva Ring +1",
		ring2="Shiva Ring +1",	
		back={ name="Campestres's Cape", augments={'Pet: Acc.+20 Pet: R.Acc.+20 Pet: Atk.+20 Pet: R.Atk.+20','Pet: Attack+10 Pet: Rng.Atk.+10',}}, 			
	})

    		
		
end

-- Select default macro book on initial load or subjob change.
function select_default_macro_book(reset)
    if reset == 'reset' then
        -- lost pet, or tried to use pact when pet is gone
    end
    -- Default macro set/book
    set_macro_page(1, 3)
end
function set_lockstyle()
    send_command('wait 6; input /lockstyleset 41')
end