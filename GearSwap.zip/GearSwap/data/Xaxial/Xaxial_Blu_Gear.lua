function user_setup()
	-- Options: Override default values
    state.OffenseMode:options('Normal','Fodder','hybrid')
	state.HybridMode:options('Normal')
    state.WeaponskillMode:options('Normal','hybrid')
    state.CastingMode:options('Normal')
    state.IdleMode:options('Normal')
	state.PhysicalDefenseMode:options('PDT')
	state.MagicalDefenseMode:options('MDT')
	state.ResistDefenseMode:options('MEVA')
	state.Weapons:options('None','Naegling','Club')

    state.ExtraMeleeMode = M{['description']='Extra Melee Mode','None','MP','SuppaBrutal','DWEarrings','DWMax'}

	gear.da_jse_back = {name="Rosmerta's Cape",augments={'DEX+20','Accuracy+20 Attack+20','Accuracy+10','"Dbl.Atk."+10',}}
	gear.stp_jse_back = {name="Rosmerta's Cape",augments={'DEX+20','Accuracy+20 Attack+20','Accuracy+10','"Store TP"+10',}}
	gear.crit_jse_back = {name="Rosmerta's Cape",augments={'DEX+20','Accuracy+20 Attack+20','DEX+10','Crit.hit rate+10',}}
	gear.wsd_jse_back = {name="Rosmerta's Cape",augments={'STR+20','Accuracy+20 Attack+20','STR+10','Weapon skill damage +10%',}}
	gear.mab_jse_back = {name="Rosmerta's Cape",augments={'INT+20','Mag. Acc+20 /Mag. Dmg.+20','"Mag.Atk.Bns."+10',}}

	gear.obi_cure_waist = "Luminary Sash"
	gear.obi_nuke_waist = "Yamabuki-no-Obi"

	-- Additional local binds
	send_command('bind ^` input /ja "Chain Affinity" <me>')
	send_command('bind @` input /ja "Efflux" <me>')
	send_command('bind !` input /ja "Burst Affinity" <me>')
	send_command('bind ^@!` gs c cycle SkillchainMode')
	send_command('bind ^backspace input /ja "Unbridled Learning" <me>;wait 1;input /ja "Diffusion" <me>;wait 2;input /ma "Mighty Guard" <me>')
	send_command('bind !backspace input /ja "Unbridled Learning" <me>;wait 1;input /ja "Diffusion" <me>;wait 2;input /ma "Carcharian Verve" <me>')
	send_command('bind @backspace input /ja "Convergence" <me>')
    send_command('bind !f11 gs c cycle ExtraMeleeMode')
	send_command('bind ^@!` gs c cycle MagicBurstMode')
	send_command('bind @f8 gs c toggle AutoNukeMode')
	send_command('bind !@^f7 gs c toggle AutoWSMode')
	send_command('bind !r gs c weapons MagicWeapons;gs c update')
	send_command('bind @q gs c weapons MaccWeapons;gs c update')
	send_command('bind ^q gs c weapons Almace;gs c update')
	send_command('bind !q gs c weapons HybridWeapons;gs c update')

	select_default_macro_book()
	set_lockstyle()
end

function init_gear_sets()

	--------------------------------------
	-- Start defining the sets
	--------------------------------------

	sets.buff['Burst Affinity'] = {feet="Hashi. Basmak +1"}
	sets.buff['Chain Affinity'] = {feet="Assim. Charuqs +2"}
	sets.buff.Convergence = {head="Luh. Keffiyeh +1"}
	sets.buff.Diffusion = {feet="Luhlaza Charuqs +1"}
	sets.buff.Enchainment = {}
	sets.buff.Efflux = {back=gear.da_jse_back,legs="Hashishin Tayt +1"}
	sets.buff.Doom = set_combine(sets.buff.Doom, {waist="Gishdubar Sash",ring1="Menelaus's Ring",neck="Nicander's Necklace",ring2="Purity Ring"})
	sets.Cursna_Received = {waist="Gishdubar Sash",ring1="Menelaus's Ring",neck="Nicander's Necklace",ring2="Purity Ring"}

	sets.HPDown = {head="Pixie Hairpin +1",ear1="Mendicant's Earring",ear2="Evans Earring",
		body="Jhakri Robe +2",hands="Jhakri Cuffs +2",ring1="Mephitas's Ring +1",ring2="Mephitas's Ring",
		back="Swith Cape +1",legs="Shedir Seraweels",feet="Jhakri Pigaches +2"}

	-- Precast Sets

	-- Precast sets to enhance JAs
	sets.precast.JA['Azure Lore'] = {hands="Luh. Bazubands +1"}


	-- Waltz set (chr and vit)
	sets.precast.Waltz = {legs="Dashing Subligar",body="Gleti's Cuirass",ring1="Valseur's Ring",ring2="Menelaus's Ring"}

	-- Don't need any special gear for Healing Waltz.
	sets.precast.Waltz['Healing Waltz'] = {}

	sets.precast.Step = {ammo="Falcon Eye",
					head="Dampening Tam",neck="Combatant's Torque",ear1="Regal Earring",ear2="Telos Earring",
					body="Assim. Jubbah +3",hands="Assim. Bazu. +3",ring1="Ramuh Ring +1",ring2="Ramuh Ring +1",
					back=gear.da_jse_back,waist="Olseni Belt",legs="Carmine Cuisses +1",feet=gear.herculean_acc_feet}

	sets.precast.Flourish1 = {ammo="Falcon Eye",
			       head="Jhakri Coronal +2",neck="Sanctity Necklace",ear1="Regal Earring",ear2="Digni. Earring",
                   body="Jhakri Robe +2",hands="Jhakri Cuffs +2",ring1="Stikini Ring",ring2="Stikini Ring",
			       back="Cornflower Cape",waist="Olseni Belt",legs="Jhakri Slops +2",feet="Jhakri Pigaches +2"}

	-- Fast cast sets for spells

	sets.precast.FC = {
    ammo="Sapience Orb",
    head="Jhakri Coronal +2",
    body="Jhakri Robe +2",
    hands="Leyline Gloves",
    legs="Ayanmo Cosciales +2",
    feet="Jhakri Pigaches +20",
    neck="Lissome Necklace",
    waist="Witful Belt",
    left_ear="Loquac. Earring",
    right_ear="Regal Earring",
    left_ring="Rahab Ring",
    right_ring="Kishar Ring",
    back={ name="Cornflower Cape", augments={'MP+25','DEX+3','Accuracy+2','Blue Magic skill +10',}},}

	sets.precast.FC.Utsusemi = set_combine(sets.precast.FC, {body="Passion Jacket"})

	sets.precast.FC['Blue Magic'] = set_combine(sets.precast.FC, {body="Hashishin Mintan +1"})


	-- Weaponskill sets
	-- Default set for any weaponskill that isn't any more specifically defined
	sets.precast.WS = {
    ammo="Oshasha's Treatise",
    head="Malignance Chapeau",
    body="Nyame Mail",
    hands="Herculean Gloves",
    legs="Nyame Flanchard",
    feet="Malignance Boots",
    neck="Fotia Gorget",
    waist="Fotia Belt",
    left_ear={ name="Moonshade Earring", augments={'Accuracy+4','TP Bonus +250',}},
    right_ear="Brutal Earring",
    left_ring="Cornelia's Ring",
    right_ring="Epaminondas's Ring",
    back="Phalangite Mantle",}

	-- Specific weaponskill sets.  Uses the base set if an appropriate WSMod version isn't found.
	sets.precast.WS['Chant du Cygne'] = set_combine(sets.precast.WS, {
	ammo="Oshasha's Treatise",
    head="Gleti's Mask",
    body="Gleti's Cuirass",
    hands="Gleti's Gauntlets",
    legs="Gleti's Breeches",
    feet="Gleti's Boots",
    neck="Mirage Stole +1",
    waist="Fotia Belt",
    left_ear="Mache Earring +1",
    right_ear="Odr Earring",
    left_ring="Cornelia's Ring",
    right_ring="Epaminondas's Ring",
    back="Phalangite Mantle",})
	
	
	sets.precast.WS['Savage Blade'] = set_combine(sets.precast.WS, {
    back="Cornflower Cape",})

	sets.precast.WS['Expiacion'] = set_combine(sets.precast.WS, {})


	-- Swap to these on Moonshade using WS if at 3000 TP
	sets.MaxTP = {ear1="Cessance Earring",ear2="Brutal Earring"}
	sets.AccMaxTP = {ear1="Regal Earring",ear2="Telos Earring"}

	-- Midcast Sets
	sets.midcast.FastRecast = {
    ammo="Staunch Tathlum",
    head="Aya. Zucchetto +2",
    body="Ayanmo Corazza +2",
    hands="Assim. Bazu. +1",
    legs="Aya. Cosciales +2",
    feet="Aya. Gambieras +2",
    neck="Lissome Necklace",
    waist="Witful Belt",
    left_ear="Loquac. Earring",
    right_ear="Regal Earring",
    left_ring="Defending Ring",
    right_ring="Kishar Ring",
    back={ name="Cornflower Cape", augments={'MP+25','DEX+3','Accuracy+2','Blue Magic skill +10',}},}

	sets.midcast['Blue Magic'] = {}

	-- Physical Spells --

	sets.midcast['Blue Magic'].Physical = {ammo="Mavi Tathlum",
		head="Lilitu Headpiece",neck="Caro Necklace",ear1="Suppanomimi",ear2="Telos Earring",
		body="Jhakri Robe +2",hands="Jhakri Cuffs +2",ring1="Ifrit Ring +1",ring2="Ilabrat Ring",
		back=gear.wsd_jse_back,waist="Grunfeld Rope",legs="Jhakri Slops +2",feet=gear.herculean_acc_feet}

	sets.midcast['Blue Magic'].Physical.Fodder = {ammo="Mavi Tathlum",
		head="Luh. Keffiyeh +1",neck="Caro Necklace",ear1="Suppanomimi",ear2="Telos Earring",
		body="Assim. Jubbah +3",hands="Jhakri Cuffs +2",ring1="Ifrit Ring +1",ring2="Ilabrat Ring",
		back="Cornflower Cape",waist="Grunfeld Rope",legs="Hashishin Tayt +1",feet="Luhlaza Charuqs +1"}

	-- Magical Spells --

	sets.midcast['Blue Magic'].Magical = {main="Bunzi's Rod",
    sub="Septoptic +1",
    ammo="Mavi Tathlum",
    head="Nyame Helm",
	body="Nyame Mail",
	hands="Nyame Gauntlets",
	legs="Nyame Flanchard",
	feet="Nyame Sollerets",
    neck="Sanctity Necklace",
    waist="Aswang Sash",
    left_ear="Hecate's Earring",
    right_ear="Regal Earring",
    left_ring="Jhakri Ring",
    right_ring="Strendu Ring",
    back={ name="Cornflower Cape", augments={'MP+25','DEX+3','Accuracy+2','Blue Magic skill +10',}},}
	

	sets.midcast['Blue Magic'].Magical.Fodder = {main="Bunzi's Rod",
    sub="Septoptic +1",
    ammo="Mavi Tathlum",
    head="Nyame Helm",
	body="Nyame Mail",
	hands="Nyame Gauntlets",
	legs="Nyame Flanchard",
	feet="Nyame Sollerets",
    neck="Sanctity Necklace",
    waist="Aswang Sash",
    left_ear="Hecate's Earring",
    right_ear="Regal Earring",
    left_ring="Jhakri Ring",
    right_ring="Strendu Ring",
    back={ name="Cornflower Cape", augments={'MP+25','DEX+3','Accuracy+2','Blue Magic skill +10',}},}

	sets.midcast['Enfeebling Magic'] = {
    ammo="Staunch Tathlum",
    head="Jhakri Coronal +2",
    body="Jhakri Robe +2",
    hands="Jhakri Cuffs +2",
    legs="Jhakri Slops +2",
    feet="Jhakri Pigaches +2",
    neck="Sanctity Necklace",
    waist="Eschan Stone",
    left_ear="Friomisi Earring",
    right_ear="Regal Earring",
    left_ring="Shiva Ring +1",
    right_ring="Shiva Ring +1",
    back={ name="Cornflower Cape", augments={'MP+25','DEX+3','Accuracy+2','Blue Magic skill +10',}},}

	sets.midcast['Enhancing Magic'] = {
    ammo="Staunch Tathlum",
    head="Aya. Zucchetto +2",
    body="Ayanmo Corazza +2",
    hands="Assim. Bazu. +1",
    legs="Aya. Cosciales +2",
    feet="Aya. Gambieras +2",
    neck="Lissome Necklace",
    waist="Siegel Sash",
    left_ear="Loquac. Earring",
    right_ear="Regal Earring",
    left_ring="Defending Ring",
    right_ring="Kishar Ring",
    back={ name="Cornflower Cape", augments={'MP+25','DEX+3','Accuracy+2','Blue Magic skill +10',}},}

	sets.midcast.Cure = {main="Nibiru Cudgel",sub="Nibiru Cudgel",ammo="Pemphredo Tathlum",
					head="Carmine Mask +1",neck="Incanter's Torque",ear1="Etiolation Earring",ear2="Mendi. Earring",
			        body="Vrikodara Jupon",hands="Telchine Gloves",ring1="Janniston Ring",ring2="Haoma's Ring",
			        back=gear.ElementalCape,waist=gear.ElementalObi,legs="Carmine Cuisses +1",feet="Medium's Sabots"}

	-- Breath Spells --

	sets.midcast['Blue Magic'].Breath = {ammo="Mavi Tathlum",
		head="Luh. Keffiyeh +1",neck="Mavi Scarf",ear1="Regal Earring",ear2="Digni. Earring",
		body="Assim. Jubbah +3",hands="Luh. Bazubands +1",ring1="Kunaji Ring",ring2="Meridian Ring",
		back="Cornflower Cape",legs="Hashishin Tayt +1",feet="Luhlaza Charuqs +1"}

	-- Physical Added Effect Spells most notably "Stun" spells --

	sets.midcast['Blue Magic'].Stun = {ammo="Pemphredo Tathlum",
			       head="Jhakri Coronal +2",neck="Erra Pendant",ear1="Regal Earring",ear2="Digni. Earring",
                   body="Jhakri Robe +2",hands="Jhakri Cuffs +2",ring1="Stikini Ring",ring2="Stikini Ring",
			       back="Cornflower Cape",waist="Luminary Sash",legs="Jhakri Slops +2",feet="Jhakri Pigaches +2"}

	sets.midcast['Blue Magic'].Stun.Fodder = sets.midcast['Blue Magic'].Stun

	-- Other Specific Spells --

	sets.midcast['Blue Magic']['White Wind'] = {main="Bunzi's Rod",sub="Sors Shield",ammo="Mavi Tathlum",
					head="Carmine Mask +1",neck="Phalaina Locket",ear1="Mendicant's Earring",ear2="Loquac. Earring",
			        body="Vrikodara Jupon",hands="Pinga Mittens",ring1="Menelaus's Ring",ring2="Lebeche Ring",
			        back=gear.ElementalCape,waist="Gishdubar Sash",legs="Gyve Trousers",feet="Medium's Sabots"}
					
	sets.midcast['Blue Magic']['Healing Breeze'] = sets.midcast['Blue Magic']['White Wind']

	sets.midcast['Blue Magic'].Healing = {main="Bunzi's Rod",sub="Sors Shield",ammo="Mavi Tathlum",
					head="Carmine Mask +1",neck="Phalaina Locket",ear1="Mendicant's Earring",ear2="Loquac. Earring",
			        body="Vrikodara Jupon",hands="Pinga Mittens",ring1="Menelaus's Ring",ring2="Lebeche Ring",
			        back=gear.ElementalCape,waist="Gishdubar Sash",legs="Gyve Trousers",feet="Medium's Sabots"}

	--Overwrite certain spells with these peices even if the day matches, because of resource inconsistancies.
	sets.NonElementalCure = {back="Tempered Cape +1",waist="Luminary Sash"}

	sets.midcast['Blue Magic'].SkillBasedBuff = {ammo="Mavi Tathlum",
		head="Luh. Keffiyeh +1",neck="Incanter's Torque",ear1="Gifted Earring",ear2="Loquac. Earring",
		body="Assim. Jubbah +3",hands="Rawhide Gloves",ring1="Stikini Ring",ring2="Stikini Ring",
		back="Cornflower Cape",waist="Witful Belt",legs="Hashishin Tayt +1",feet="Luhlaza Charuqs +1"}

	sets.midcast['Blue Magic'].Buff = {main="Vampirism",sub="Vampirism",ammo="Mavi Tathlum",
		head="Luh. Keffiyeh +1",neck="Incanter's Torque",ear1="Gifted Earring",ear2="Loquac. Earring",
		body="Assim. Jubbah +3",hands="Hashi. Bazu. +1",ring1="Kishar Ring",ring2="Dark Ring",
		back="Aurist's Cape +1",waist="Witful Belt",legs="Lengo Pants",feet="Carmine Greaves +1"}

	sets.midcast['Blue Magic']['Battery Charge'] = set_combine(sets.midcast['Blue Magic'].Buff, {head="Amalric Coif +1",back="Grapevine Cape",waist="Gishdubar Sash"})

	sets.midcast['Blue Magic']['Carcharian Verve'] = set_combine(sets.midcast['Blue Magic'].Buff, {head="Amalric Coif +1",hands="Regal Cuffs",waist="Emphatikos Rope",legs="Shedir Seraweels"})

	-- Sets to return to when not performing an action.

	sets.latent_refresh = {waist="Fucho-no-obi"}
	sets.DayIdle = {}
	sets.NightIdle = {}

	-- Gear for learning spells: +skill and AF hands.
	sets.Learning = {hands="Assim. Bazu. +1"}

	-- Resting sets
	sets.resting = {main="Bolelabunga",sub="Genmei Shield",ammo="Falcon Eye",
			      head="Rawhide Mask",neck="Loricate Torque +1",ear1="Etiolation Earring", ear2="Ethereal Earring",
			      body="Jhakri Robe +2",hands=gear.herculean_refresh_hands,ring1="Defending Ring",ring2="Sheltered Ring",
			      back="Bleating Mantle",waist="Flume Belt",legs="Lengo Pants",feet=gear.herculean_refresh_feet}

	-- Idle sets
	sets.idle = {
    ammo="Staunch Tathlum",
    head="Gleti's Mask",
    body="Jhakri Robe +2",
    hands="Gleti's Gauntlets",
    legs={ name="Carmine Cuisses +1", augments={'Accuracy+20','Attack+12','"Dual Wield"+6',}},
    feet="Gleti's Boots",
    neck="Sanctity Necklace",
    waist="Flume Belt +1",
    left_ear="Cessance Earring",
    right_ear="Regal Earring",
    left_ring="Defending Ring",
    right_ring="Warp Ring",
    back="Repulse Mantle",}

	-- Defense sets
	sets.defense.PDT = {
    ammo="Staunch Tathlum",
    head="Aya. Zucchetto +2",
    body="Ayanmo Corazza +2",
    hands="Aya. Manopolas +1",
    legs="Aya. Cosciales +2",
    feet="Aya. Gambieras +2",
    neck={ name="Loricate Torque +1", augments={'Path: A',}},
    waist="Flume Belt +1",
    left_ear="Friomisi Earring",
    right_ear="Regal Earring",
    left_ring="Defending Ring",
    right_ring="Vocane Ring",
    back="Repulse Mantle",}

	sets.defense.MDT = {
    ammo="Staunch Tathlum",
    head="Aya. Zucchetto +2",
    body="Ayanmo Corazza +2",
    hands="Aya. Manopolas +1",
    legs="Aya. Cosciales +2",
    feet="Aya. Gambieras +2",
    neck={ name="Loricate Torque +1", augments={'Path: A',}},
    waist="Flume Belt +1",
    left_ear="Friomisi Earring",
    right_ear="Regal Earring",
    left_ring="Defending Ring",
    right_ring="Vocane Ring",
    back="Repulse Mantle",}

    sets.defense.MEVA = {
    ammo="Staunch Tathlum",
    head="Aya. Zucchetto +2",
    body="Ayanmo Corazza +2",
    hands="Aya. Manopolas +1",
    legs="Aya. Cosciales +2",
    feet="Aya. Gambieras +2",
    neck={ name="Loricate Torque +1", augments={'Path: A',}},
    waist="Flume Belt +1",
    left_ear="Friomisi Earring",
    right_ear="Regal Earring",
    left_ring="Defending Ring",
    right_ring="Vocane Ring",
    back="Repulse Mantle",}

	sets.defense.NukeLock = sets.midcast['Blue Magic'].Magical

	sets.Kiting = {legs="Carmine Cuisses +1"}

    -- Extra Melee sets.  Apply these on top of melee sets.
    sets.Knockback = {}
    sets.MP = {waist="Flume Belt",ear1="Suppanomimi", ear2="Ethereal Earring"}
    sets.MP_Knockback = {}
	sets.SuppaBrutal = {ear1="Suppanomimi", ear2="Brutal Earring"}
	sets.DWEarrings = {ear1="Dudgeon Earring",ear2="Heartseeker Earring"}
	sets.DWMax = {ear1="Dudgeon Earring",ear2="Heartseeker Earring",body="Adhemar Jacket +1",waist="Reiki Yotai",legs="Carmine Cuisses +1"}
	sets.TreasureHunter = set_combine(sets.TreasureHunter, {})
	sets.Assault = {ring1="Balrahn's Ring"}
	
	-- Weapons sets
	sets.weapons.None = {main="",sub=""}
	sets.weapons.Naegling = {main="Naegling",sub="Sakpata's Sword"}
	sets.weapons.Club = {main="Maxentius",sub="Septoptic +1"}

	-- Engaged sets

	sets.engaged = {
	main="Naegling",
	sub="Sakpata's Sword",
    ammo="Ginsen",
    head="Malignance Chapeau",
    body="Adhemar Jacket +1",
    hands="Herculean Gloves",
    legs="Samnuha Tights",
    feet="Malignance Boots",
    neck="Mirage Stole +1",
    waist="Reiki Yotai",
    left_ear="Cessance Earring",
    right_ear="Brutal Earring",
    left_ring="Hetairoi ring",
    right_ring="Epona's Ring",
    back="Atheling Mantle",}

	sets.engaged.hybrid = {			--49%DT Total with Sakpata sword --
    ammo="Staunch Tathlum",			--2%DT
    head="Malignance Chapeau",		--6%DT
    body="Ayanmo Corazza +2",		--6%DT
    hands="Ayanmo Manopolas +2",	--3%DT
    legs="Ayanmo Cosciales +2",		--5%DT
    feet="Malignance Boots",		--4%DT
    neck="Lissome Necklace",		
    waist="Platinum Moogle Belt",	--3%DT
    left_ear="Brutal Earring",
    right_ear="Cessance Earring",
    left_ring="Defending Ring",		--10%DT
    right_ring="Epona's Ring",	
    back="Atheling Mantle",}			

	sets.engaged.Fodder = {
    main="Naegling",
	sub="Sakpata's Sword",
    ammo="Ginsen",
    head="Malignance Chapeau",
    body="Adhemar Jacket +1",
    hands="Herculean Gloves",
    legs="Samnuha Tights",
    feet="Malignance Boots",
    neck="Mirage Stole +1",
    waist="Reiki Yotai",
    left_ear="Cessance Earring",
    right_ear="Brutal Earring",
    left_ring="Hetairoi ring",
    right_ring="Epona's Ring",
    back="Atheling Mantle",}

	sets.Self_Healing = {neck="Phalaina Locket",hands="Buremte Gloves",legs="Gyve Trousers",ring2="Kunaji Ring",waist="Gishdubar Sash"}
	sets.Self_Healing_Club = {neck="Phalaina Locket",hands="Buremte Gloves",ring2="Kunaji Ring",waist="Gishdubar Sash"}
	sets.Self_Healing_DWClub = {neck="Phalaina Locket",hands="Buremte Gloves",ring2="Kunaji Ring",waist="Gishdubar Sash"}
	sets.Healing_Club = {}
	sets.Healing_DWClub = {}
	sets.Cure_Received = {neck="Phalaina Locket",hands="Buremte Gloves",ring2="Kunaji Ring",waist="Gishdubar Sash"}
	sets.Self_Refresh = {back="Grapevine Cape",waist="Gishdubar Sash"}
	sets.MagicBurst = {body="Samnuha Coat",hands="Amalric Gages +1",ring1="Mujin Band",ring2="Locus Ring"}

end

-- Select default macro book on initial load or subjob change.
function select_default_macro_book()
	-- Default macro set/book
	if player.sub_job == 'DNC' then
		set_macro_page(1, 7)
	elseif player.sub_job == 'NIN' then
		set_macro_page(1, 7)
	elseif player.sub_job == 'WAR' then
		set_macro_page(1, 7)
	elseif player.sub_job == 'RUN' then
		set_macro_page(1, 7)
	elseif player.sub_job == 'BLM' then
		set_macro_page(2, 7)
	elseif player.sub_job == 'RDM' then
		set_macro_page(2, 7)
	else
		set_macro_page(1, 7)
	end
end

function set_lockstyle()
    send_command('wait 6; input /lockstyleset 025')
end