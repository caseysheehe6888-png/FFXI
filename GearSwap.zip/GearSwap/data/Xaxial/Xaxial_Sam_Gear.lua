-- Setup vars that are user-dependent.
function user_setup()
    state.OffenseMode:options('Normal','Acc','MEva','Hybrid')
    state.HybridMode:options('Normal')
    state.WeaponskillMode:options('Normal','Acc','Hybrid')
    state.RangedMode:options('Normal')
    state.PhysicalDefenseMode:options('PDT')
	state.MagicalDefenseMode:options('MDT')
	state.ResistDefenseMode:options('MEVA')
    state.IdleMode:options('Normal', 'PDT')
	state.Weapons:options('None','Masamune','Doji','Soboro','ShiningOne')

    state.ExtraMeleeMode = M{['description']='Extra Melee Mode', 'None','STPMax'}

    -- Additional local binds
--    send_command('bind ^` input /ja "Hasso" <me>')
--    send_command('bind !` input /ja "Seigan" <me>')
--	send_command('bind !backspace input /ja "Third Eye" <me>')
	send_command('bind ^` gs c cycle Weapons')
	send_command('bind ^f7 gs c cycleback Weapons')	
	send_command('bind @` gs c cycle AutoShadowMode')	
	send_command('bind ` gs c cycle ExtraMeleeMode')	
	send_command('bind !` gs c cycle Stance')
--	send_command('bind !` gs c cycle SkillchainMode')
--	send_command('bind !r gs c weapons ProcWeapon;gs c set WeaponskillMode Proc;gs c update')
--	send_command('bind ^r gs c weapons Default;gs c set WeaponskillMode Normal;gs c update')
--	send_command('bind ^q gs c weapons Bow;gs c update')

    select_default_macro_book()
	set_lockstyle()

end

-- Define sets and vars used by this job file.
function init_gear_sets()

	-- Weapons sets

	sets.weapons.Doji = {main="Dojikiri Yasutsuna",sub="Utu Grip"}
	sets.weapons.Soboro = {main="Soboro Sukehiro",sub="Utu Grip"}
	sets.weapons.Masamune = {main="Masamune",sub="Utu Grip"}
	sets.weapons.ShiningOne = {main="Shining One",sub="Utu Grip"}
	
	sets.STPMax = {
    }

	-- Buff sets
    sets.Enmity = {
		ammo="Sapience Orb",
		head="Halitus Helm",
		body="Emet Harness +1",
		hands="Kurys Gloves",
		legs="Kendatsuba Hakama +1",
		feet="Ahosi Leggings",
		neck="Loricate Torque +1",
		waist="Goading Belt",
		ear1="Friomisi Earring",
		ear2="Cryptic Earring",
		ring1="Supershear Ring",
		ring2="Begrudging Ring",
		back="Phalangite Mantle"
        }

	sets.midcast.Flash = set_combine(sets.Enmity,{})
	
	sets.Cure_Received = {}
	sets.buff.Doom = set_combine(sets.buff.Doom, {ring1="Eshmun's Ring",ring2="Eshmun's Ring"})
	sets.buff.Sleep = {neck="Dualism Collar +1",waist="Oneiros Belt",ear1="Odnowa Earring",ear2="Odnowa Earring +1",back="Moonlight Cape"}
	sets.buff.Hasso = {hands="Wakido Kote +3"}
	sets.buff.Seigan = {legs="Sakonji Haidate +3"}


    sets.buff.Sekkanoki = {hands="Kasuga Kote +1"}
    sets.buff.Sengikori = {feet="Kas. Sune-Ate +1"}
    sets.buff['Meikyo Shisui'] = {feet="Sakonji Sune-Ate +2"}

    --------------------------------------
    -- Start defining the sets
    --------------------------------------
    
	sets.TreasureHunter = set_combine(sets.TreasureHunter, {Ammo="Perfect Lucky Egg",feet="Volte Boots",belt="Chaac Belt",head="White Rarab Cap +1"})
	
    -- Precast Sets
    -- Precast sets to enhance JAs
    sets.precast.JA.Meditate = {head="Wakido Kabuto +1",hands="Sakonji Kote +2",back="Smertrios's Mantle"}
    sets.precast.JA['Warding Circle'] = {head="Wakido Kabuto +1"}
    sets.precast.JA['Blade Bash'] = {hands="Sakonji Kote +2"}
	sets.precast.JA['Sekkanoki'] = {hands="Kasuga Kote +1"}
	sets.precast.JA['Sengikori'] = {feet="Kas. Sune-Ate +1"}
	sets.precast.JA['Shikikoyo'] = {legs="Sakonji Haidate +3"}
	sets.precast.JA['Jump'] = set_combine(sets.precast.WS['Tachi: Jinpu'], {})
	sets.precast.JA['High Jump'] = set_combine(sets.precast.WS['Tachi: Jinpu'], {})


    sets.precast.Step = {}
    sets.precast.JA['Violent Flourish'] = {}
    sets.precast.Waltz = {}        
    sets.precast.Waltz['Healing Waltz'] = {}

    -- Fast cast sets for spells
    sets.precast.FC = {
		ammo="Sapience Orb",
		legs="Arjuna Breeches",
		waist="Goading Belt",
		neck="Voltsurge Torque",
		ear1="Enchntr. Earring +1",
		ear2="Loquacious Earring",
		ring1="Prolix Ring",
		ring2="Kishar Ring",
	}
	   
    -- Ranged snapshot gear
    sets.precast.RA = {}
	   

	-- Swap to these on Moonshade using WS if at 3000 TP
	sets.MaxTP = {ear2="Brutal Earring"}
	sets.AccMaxTP = {ear2="Brutal Earring"}
	sets.AccDayMaxTPWSEars = {ear2="Brutal Earring"}
	sets.DayMaxTPWSEars = {ear2="Brutal Earring"}
	sets.AccDayWSEars = {ear2="Brutal Earring"}
	sets.DayWSEars = {ear2="Brutal Earring"}
	
    -- Midcast Sets
    sets.midcast.FastRecast = set_combine(sets.precast.FC,{})
    sets.midcast.Utsusemi = set_combine(sets.midcast.FastRecast, {})

    -- Ranged gear
    sets.midcast.RA = {
		}

    sets.midcast.RA.Acc = set_combine(sets.midcast.RA,{})
    
    -- Resting sets
	
    sets.idle = {
		ammo="Ginsen",
		head={ name="Valorous Mask", augments={'"Mag.Atk.Bns."+12','Weapon skill damage +3%','STR+15','Attack+12',}}, --Wakido Kabuto +1
		body="Kendatsuba Samue +1",
		hands="Kendatsuba Tekko +1",
		legs="Kendatsuba Hakama +1",
		feet="Kendatsuba Sune-ate +1",
		neck="Samurai's Nodowa +2",
		waist="Ioskeha Belt +1",
		ear1="Brutal Earring",
		ear2="Cessance Earring",
		ring1="Niqmaddu Ring",
		ring2="Karieyh Ring",
        back={ name="Smertrios's Mantle", augments={'DEX+20','Accuracy+20 Attack+20','Accuracy+10','"Dbl.Atk."+10','Phys. dmg. taken-10%',}},
		}
	
	sets.idle.PDT = {
		ammo="Staunch Tathlum",
		head="Kendatsuba Jinpachi +1",
		body="Wakido Domaru +3",
		hands="Sakonji Kote +2",
		legs="Kendatsuba Hakama +1",
		feet="Kendatsuba Sune-ate +1",
		neck="Loricate Torque +1",
		waist="Flume Belt +1",
		ear1="Genmei earring",
		ear2="Etiolation Earring",
		ring1="Defending Ring",
		ring2="Gelatinous Ring +1",
		back={ name="Smertrios's Mantle", augments={'DEX+20','Accuracy+20 Attack+20','Accuracy+10','"Dbl.Atk."+10','Phys. dmg. taken-10%',}},	
	}
	
    sets.idle.Reraise = set_combine(sets.idle, {})
    sets.idle.Weak = set_combine(sets.idle, {})	
    sets.idle.Weak.Reraise = set_combine(sets.idle.Weak, sets.Reraise)	
	sets.DayIdle = {}
	sets.NightIdle = {}
    sets.resting = set_combine(sets.idle,{})
    

    -- Idle sets (default idle set not needed since the other three are defined, but leaving for testing purposes)
	
	sets.Kiting = {feet="Danzo Sune-Ate"}
	sets.Town = set_combine(sets.idle,{
		head="Kendatsuba Jinpachi +1",
		body="Kendatsuba Samue +1",
		hands="Kendatsuba Tekko +1",
		legs="Kendatsuba Hakama +1",
		feet="Danzo Sune-Ate",})
		
    sets.Reraise = {}
	sets.TreasureHunter = set_combine(sets.engaged, {head="Wh. Rarab Cap +1", hands="Volte Bracers", waist="Chaac Belt"})
	sets.Skillchain = {}

    
    -- Defense sets
    sets.defense.PDT = set_combine(sets.idle.PDT,{
		ammo="Staunch Tathlum",
		head="Kendatsuba Jinpachi +1",
		body="Wakido Domaru +3",
		hands="Sakonji Kote +2",
		legs="Kendatsuba Hakama +1",
		feet="Kendatsuba Sune-ate +1",
		neck="Loricate Torque +1",
		waist="Flume Belt +1",
		ear1="Odnowa Earring +1",
		ear2="Odnowa Earring",
		ring1="Defending Ring",
		ring2="Gelatinous Ring +1",
		back={ name="Smertrios's Mantle", augments={'DEX+20','Accuracy+20 Attack+20','Accuracy+10','"Dbl.Atk."+10','Phys. dmg. taken-10%',}},	
	})

    sets.defense.PDTReraise = set_combine(sets.defense.PDT, {})
		
    sets.defense.MDT = set_combine(sets.defense.PDT,{
		head="Kendatsuba Jinpachi +1",
		body="Kendatsuba Samue +1",
		hands="Kendatsuba Tekko +1",
		legs="Kendatsuba Hakama +1",
		--legs="Sakonji Haidate +3",
		feet="Kendatsuba Sune-ate +1",
		ear1="Odnowa Earring +1",
		ear2="Etiolation Earring",
		ring2="Fortified Ring",
		back={ name="Smertrios's Mantle", augments={'STR+20','Accuracy+20 Attack+20','STR+10','Weapon skill damage +10%','Mag. Evasion+15',}},
	})
	
	sets.defense.MDTReraise = set_combine(sets.defense.MDT, {})
    
	sets.defense.MEVA = set_combine(sets.defense.PDT,{
		head="Kendatsuba Jinpachi +1",
		body="Kendatsuba Samue +1",
		hands="Kendatsuba Tekko +1",
		legs="Kendatsuba Hakama +1",
		feet="Kendatsuba Sune-ate +1",	
	})
	
    -- Engaged sets

    -- Variations for TP weapon and (optional) offense/defense modes.  Code will fall back on previous
    -- sets if more refined versions aren't defined.
    -- If you create a set with both offense and defense modes, the offense mode should be first.
    -- EG: sets.engaged.Dagger.Accuracy.Evasion
    
    -- Normal melee group
    -- Delay 450 GK, 25 Save TP => 65 Store TP for a 5-hit (25 Store TP in gear)
    sets.engaged = {
		ammo="Ginsen",
		head="Flamma Zucchetto +2",
		body="Kendatsuba Samue +1",
		hands="Wakido Kote +3",
		legs="Ryuo Hakama +1", --Kendatsuba Hakama +1
		feet="Ryuo Sune-Ate +1",
		neck="Samurai's Nodowa +2",
		waist="Ioskeha Belt +1",
		ear1="Brutal Earring",
		ear2="Cessance Earring",
		ring1="Niqmaddu Ring",
		ring2="Flamma Ring",
        back={ name="Smertrios's Mantle", augments={'DEX+20','Accuracy+20 Attack+20','Accuracy+10','"Dbl.Atk."+10','Phys. dmg. taken-10%',}},		
	}
	
    sets.engaged.Acc = set_combine(sets.engaged,{
		ammo="Ginsen",
		head="Flamma Zucchetto +2",
		body="Kendatsuba Samue +1",
		hands="Wakido Kote +3",
		legs="Kendatsuba Hakama +1",
		feet="Flamma Gambieras +2",
		neck="Samurai's Nodowa +2",
		waist="Ioskeha Belt +1",
		ear1="Telos Earring",
		ear2="Cessance Earring",
		ring1={ name="Chirich Ring +1", bag="wardrobe"},
		ring2="Flamma Ring",	  	
        back={ name="Smertrios's Mantle", augments={'DEX+20','Accuracy+20 Attack+20','Accuracy+10','"Dbl.Atk."+10','Phys. dmg. taken-10%',}},				
	})

    sets.engaged.MEva = set_combine(sets.engaged,{
		ammo="Ginsen",
		head="Kendatsuba Jinpachi +1",
		body="Kendatsuba Samue +1",
		hands="Wakido Kote +3",
		legs="Kendatsuba Hakama +1",
		feet="Kendatsuba Sune-ate +1",
		neck="Samurai's Nodowa +2",
		waist="Ioskeha Belt +1",
		ear1="Brutal Earring",
		ear2="Cessance Earring",
		ring1="Niqmaddu Ring",
		ring2={ name="Chirich Ring +1", bag="wardrobe2"},
        back={ name="Smertrios's Mantle", augments={'DEX+20','Accuracy+20 Attack+20','Accuracy+10','"Dbl.Atk."+10','Phys. dmg. taken-10%',}},	
	})

	sets.engaged.Hybrid = set_combine(sets.engaged,{
		ammo="Staunch Tathlum",
		head="Kendatsuba Jinpachi +1",
		body="Wakido Domaru +3",
		hands="Wakido Kote +3",
		legs="Kendatsuba Hakama +1",
		feet="Kendatsuba Sune-ate +1",
		neck="Loricate Torque +1",
		waist="Flume Belt +1",
		ear1="Genmei Earring",
		ear2="Odnowa Earring +1",
		ring1="Gelatinous Ring +1",
		ring2="Defending Ring",
        back={ name="Smertrios's Mantle", augments={'DEX+20','Accuracy+20 Attack+20','Accuracy+10','"Dbl.Atk."+10','Phys. dmg. taken-10%',}},		
	})

	sets.engaged.Ambus = set_combine(sets.engaged,{
		ammo="Focal Orb", --ammo="Staunch Tathlum", or Ginsen
		head="Flamma Zucchetto +2", --head="Kendatsuba Jinpachi +1",
		body="Kendatsuba Samue +1",
		hands="Wakido Kote +3", --hands="Kendatsuba Tekko +1",
		legs="Kendatsuba Hakama +1",
		feet="Kendatsuba Sune-ate +1",
		neck="Samurai's Nodowa +2",
		waist="Ioskeha Belt +1",
		ear1="Cessance Earring", --Telos Earring
		ear2="Brutal Earring", --Cessance Earring
		ring1="Niqmaddu Ring",
		ring2="Hetairoi Ring", --ring2={ name="Chirich Ring +1", bag="wardrobe2"},
        back={ name="Smertrios's Mantle", augments={'DEX+20','Accuracy+20 Attack+20','Accuracy+10','"Dbl.Atk."+10','Phys. dmg. taken-10%',}},	
	})
		
    -- Weaponskill sets
    -- Default set for any weaponskill that isn't any more specifically defined
    sets.precast.WS = {
		ammo="Knobkierrie",
		head={ name="Valorous Mask", augments={'"Mag.Atk.Bns."+12','Weapon skill damage +3%','STR+15','Attack+12',}},
		body="Sakonji Domaru +3",
		hands={ name="Valorous Mitts", augments={'Accuracy+21','Weapon skill damage +3%','STR+14',}},
		legs="Wakido Haidate +3",
		feet="Valorous Greaves",
		neck="Samurai's Nodowa +2",
		waist="Fotia Belt",
		ear1="Ishvara Earring", --Thrud Earring
		ear2="Moonshade Earring",
		ring1="Regal Ring",
		ring2="Karieyh Ring",
        back={ name="Smertrios's Mantle", augments={'STR+20','Accuracy+20 Attack+20','STR+10','Weapon skill damage +10%','Mag. Evasion+15',}},
	}
	
	sets.precast.WS.Acc = set_combine(sets.precast.WS, {})
	sets.precast.WS.Hybrid = set_combine(sets.precast.WS, {})
	
	
    -- Specific weaponskill sets.  Uses the base set if an appropriate WSMod version isn't found.
    sets.precast.WS['Impulse Drive'] = set_combine(sets.precast.WS, {})
    sets.precast.WS['Impulse Drive'].Acc = set_combine(sets.precast.WS.Acc, {})

    sets.precast.WS['Tachi: Fudo'] = set_combine(sets.precast.WS, {})
    sets.precast.WS['Tachi: Fudo'].Acc = set_combine(sets.precast.WS.Acc, {})
	
    sets.precast.WS['Tachi: Shoha'] = set_combine(sets.precast.WS, {})
    sets.precast.WS['Tachi: Shoha'].Acc = set_combine(sets.precast.WS.Acc, {})

    sets.precast.WS['Tachi: Rana'] = set_combine(sets.precast.WS, {})
    sets.precast.WS['Tachi: Rana'].Acc = set_combine(sets.precast.WS.Acc, {})

    sets.precast.WS['Tachi: Kasha'] = set_combine(sets.precast.WS, {})
    sets.precast.WS['Tachi: Kasha'].Acc = set_combine(sets.precast.WS.Acc, {})

    sets.precast.WS['Tachi: Gekko'] = set_combine(sets.precast.WS, {})
    sets.precast.WS['Tachi: Gekko'].Acc = set_combine(sets.precast.WS.Acc, {})

    sets.precast.WS['Tachi: Yukikaze'] = set_combine(sets.precast.WS, {})
    sets.precast.WS['Tachi: Yukikaze'].Acc = set_combine(sets.precast.WS.Acc, {})

    sets.precast.WS['Tachi: Ageha'] = set_combine(sets.precast.WS, {
		head="Flamma Zucchetto +2",
		body="Flamma Korazin +2",
		hands="Flam. Manopolas +2",
		legs="Flamma Dirs +2",
		feet="Flamma Gambieras +2",
	})
	
    sets.precast.WS['Tachi: Hobaku'] = set_combine(sets.precast.WS, {})		
    
	sets.precast.WS['Tachi: Jinpu'] = set_combine(sets.precast.WS, {
		ammo="Ginsen",
		head="Kendatsuba Jinpachi +1",
		body="Kendatsuba Samue +1",
		hands="Kendatsuba Tekko +1",
		legs="Kendatsuba Hakama +1",
		feet="Kendatsuba Sune-ate +1",
		neck="Samurai's Nodowa +2",
		waist="Ioskeha Belt +1",
		ear1="Telos Earring",
		ear2="Dignitary's Earring",
		ring1={ name="Chirich Ring +1", bag="wardrobe"},
		ring2={ name="Chirich Ring +1", bag="wardrobe2"},
		back={ name="Smertrios's Mantle", augments={'DEX+20','Accuracy+20 Attack+20','Accuracy+10','"Dbl.Atk."+10','Phys. dmg. taken-10%',}},
	})

    sets.precast.WS['Apex Arrow'] = set_combine(sets.precast.WS, {})
    sets.precast.WS['Apex Arrow'].Acc = set_combine(sets.precast.WS['Apex Arrow'], {})

	
    sets.engaged.Reraise = set_combine(sets.engaged, {})		
    sets.engaged.Acc.Reraise = set_combine(sets.engaged.Acc, {})		


end

-- Select default macro book on initial load or subjob change.
function select_default_macro_book()
    
	if player.sub_job == 'WAR' then
		set_macro_page(1, 1)
	elseif player.sub_job == 'DRG' then
		set_macro_page(2, 1)
	end
end

function set_lockstyle()
    send_command('wait 6; input /lockstyleset 41')
end