-- Setup vars that are user-dependent.  Can override this function in a sidecar file.
function user_setup()
    state.OffenseMode:options('Normal','Acc')
    state.RangedMode:options('Normal', 'Acc')
    state.WeaponskillMode:options('Match','Normal', 'Acc')
    state.CastingMode:options('Normal', 'Resistant')
    state.IdleMode:options('Normal', 'PDT', 'Refresh')
	state.ExtraMeleeMode = M{['description']='Extra Melee Mode', 'None', 'DWMax'}
	state.Weapons:options('LeadenWeapons','SavageWeapons','LastStandWeapons','DualRangedWeapons','None') --'Default',
	state.CompensatorMode:options('500','1000','Never','Always')
	
    gear.RAbullet = "Chrono Bullet"
    gear.WSbullet = "Chrono Bullet"
    gear.MAbullet = "Living Bullet" --For MAB WS, do not put single-use bullets here.
    gear.QDbullet = "Animikii Bullet"
    options.ammo_warning_limit = 15

	autows = 'Last Stand'	

	gear.snapshot_jse_back = {name="Camulus's Mantle",augments={'"Snapshot"+10',}}																--snapshot
	gear.tp_range_jse_back = {name="Camulus's Mantle",augments={'AGI+20','Rng.Acc.+20 Rng.Atk.+20','Rng.Acc.+10','"Store TP"+10',}}				--RA TP	
	gear.tp_dbl_jse_back = {name="Camulus's Mantle",augments={'DEX+20','Accuracy+20 Attack+20','Accuracy+10','"Dbl. Atk."+10',}}				--melee dbl atk
	gear.ranger_wsd_jse_back = {name="Camulus's Mantle",augments={'AGI+20','Rng.Acc.+20 Rng.Atk.+20','AGI+10','Weapon skill damage +10%',}}		--RA WS
	gear.magic_wsd_jse_back = {name="Camulus's Mantle",augments={'AGI+20','Mag. Acc+20 Mag. Dmg.+20','AGI+10','Weapon skill damage +10%',}}		--Magic WS
	gear.str_wsd_jse_back = {name="Camulus's Mantle",augments={'STR+20','Accuracy+20 Attack+20','STR+10','Weapon skill damage +10%',}}			--savage blade


	--[[Global binds you may want to change.
	Bind special characters.
	@ = Windows Key
	% = Works only when text bar not up.
	$ = Works only when text bar is up.
	^ = Control Key
	! = Alt Key
	~ = Shift Key
	# = Apps Key
]]
	
    -- Additional local binds
	send_command('bind !f11 gs c cycle ExtraMeleeMode')
	send_command('bind ^` gs c cycle ElementalMode')
	send_command('bind !` gs c elemental quickdraw')
	
	send_command('bind ^backspace input /ja "Double-up" <me>')
	send_command('bind @backspace input /ja "Snake Eye" <me>')
	send_command('bind !backspace input /ja "Fold" <me>')
	send_command('bind ^@!backspace input /ja "Crooked Cards" <me>')
	send_command('bind ^\\\\ input /ja "Random Deal" <me>')
    send_command('bind !\\\\ input /ja "Bolter\'s Roll" <me>')

	send_command('bind ^@!\\\\ gs c toggle LuzafRing')
	send_command('bind @f7 gs c toggle RngHelper')

	--send_command('bind !r gs c weapons SingleWeapon;gs c update')
	send_command('bind @q gs c weapons MaccWeapons;gs c update')
	send_command('bind ^q gs c weapons DualRangedWeapons;gs c update')
	send_command('bind !q gs c weapons SavageWeapons;gs c update')
	send_command('bind @pause roller roll')

    select_default_macro_book()
end

-- Define sets and vars used by this job file.
function init_gear_sets()
    --------------------------------------
    -- Start defining the sets
    --------------------------------------

    -- Precast Sets

    -- Precast sets to enhance JAs

	sets.precast.JA['Triple Shot'] = {body="Chasseur's Frac +1"}
    sets.precast.JA['Snake Eye'] = {legs="Lanun Trews"}
    sets.precast.JA['Wild Card'] = {feet="Lanun Bottes +3"}
    sets.precast.JA['Random Deal'] = {body="Lanun Frac +3"}
    sets.precast.FoldDoubleBust = {hands="Lanun Gants +1"}

    sets.precast.CorsairRoll = {
        head="Lanun Tricorne +2",
		neck="Regal Necklace",
		ear1="Etiolation Earring",
		ear2="Sanare Earring",
        body="Lanun Frac +3",
		hands="Chasseur's Gants +1",
		ring1="Defending Ring",
		ring2="Dark Ring",
        back=gear.tp_dbl_jse_back,
		waist="Flume Belt +1",
		legs="Mummu Kecks +1",
		feet="Lanun Bottes +3"}

    sets.precast.LuzafRing = {ring2="Luzaf's Ring"}
    
    sets.precast.CorsairRoll["Caster's Roll"] = set_combine(sets.precast.CorsairRoll, {legs="Chas. Culottes +1"})
    sets.precast.CorsairRoll["Courser's Roll"] = set_combine(sets.precast.CorsairRoll, {feet="Chass. Bottes +1"})
    sets.precast.CorsairRoll["Blitzer's Roll"] = set_combine(sets.precast.CorsairRoll, {head="Chass. Tricorne +1"})
    sets.precast.CorsairRoll["Tactician's Roll"] = set_combine(sets.precast.CorsairRoll, {body="Chasseur's Frac +1"})
    sets.precast.CorsairRoll["Allies' Roll"] = set_combine(sets.precast.CorsairRoll, {hands="Chasseur's Gants +1"})
    
    sets.precast.CorsairShot = {
		ammo=gear.QDbullet,
		head="Laksa. Tricorne +3",
		neck="Sanctity Necklace",
		ear1="Friomisi Earring",
		ear2="Crematio Earring",
        body="Samnuha Coat",
		hands="Leyline Gloves",
		ring1="Shiva Ring +1",
		ring2="Ilabrat Ring",
        back=gear.ranger_wsd_jse_back,
		waist="Eschan Stone",
		legs="Mummu Kecks +1",
		feet="Chass. Bottes +1"}

    sets.precast.CorsairShot['Light Shot'] = {
		ammo=gear.QDbullet,
		head="Laksa. Tricorne +3",
		neck="Sanctity Necklace",
		ear1="Digni. Earring",
		ear2="Telos Earring",
        body="Mummu Jacket +2",
		hands="Leyline Gloves",
		ring1="Stikini Ring +1",
		ring2="Stikini Ring +1",
        back=gear.ranger_wsd_jse_back,
		waist="Eschan Stone",
		legs="Mummu Kecks +2",
		feet="Mummu Gamash. +2"}

    sets.precast.CorsairShot['Dark Shot'] = set_combine(sets.precast.CorsairShot['Light Shot'], {feet="Chass. Bottes +1"})

    -- Waltz set (chr and vit)
    sets.precast.Waltz = {
        head="Carmine Mask +1",neck="Loricate Torque +1",ear1="Etiolation Earring",ear2="Sanare Earring",
        body=gear.herculean_waltz_body,hands=gear.herculean_waltz_hands,ring1="Defending Ring",ring2="Valseur's Ring",
        back="Moonlight Cape",waist="Flume Belt +1",legs="Dashing Subligar",feet=gear.herculean_waltz_feet}
		
	sets.Self_Waltz = {head="Mummu Bonnet +2",body="Passion Jacket",ring1="Asklepian Ring"}
        
    -- Don't need any special gear for Healing Waltz.
    sets.precast.Waltz['Healing Waltz'] = {}

    -- Fast cast sets for spells
    
    sets.precast.FC = {
        head="Carmine Mask +1",neck="Baetyl Pendant",ear1="Enchntr. Earring +1",ear2="Loquacious Earring",
        body="Dread Jupon",hands="Leyline Gloves",ring1="Kishar Ring",ring2="Lebeche Ring",
        back="Moonlight Cape",waist="Flume Belt +1",legs="Rawhide Trousers",feet="Carmine Greaves +1"}

    sets.precast.FC.Utsusemi = set_combine(sets.precast.FC, {neck="Magoraga Beads",body="Passion Jacket"})
	
	sets.precast.FC.Cure = set_combine(sets.precast.FC, {ear2="Mendi. Earring"})
	-- Snapshot/Rapidshot 70cap -10 from JP
	-- 60
    sets.precast.RA = {	
		ammo=gear.RAbullet,
        head="Taeon Chapeau",			-- 10
        body="Oshosi Vest +1",			-- 14 
		hands="Carmine Fin. Ga. +1",	--  8/11
		back=gear.snapshot_jse_back,	-- 10
		waist="Impulse Belt",			--  3
		legs="Adhemar Kecks +1",		-- 10
		feet="Meg. Jam. +2",			-- 10

		}	-- 65/11
	-- 45 
	sets.precast.RA.Flurry = set_combine(sets.precast.RA, {
		body="Laksa. Frac +3"			-- 0/20
		})	--51/31
	-- 30
	sets.precast.RA.Flurry2 = set_combine(sets.precast.RA.Flurry, {
		head="Chass. Tricorne +1",		-- 0/14
		feet="Pursuer's Gaiters"		-- 0/10
		})	--41/55

       
    -- Weaponskill sets
    -- Default set for any weaponskill that isn't any more specifically defined
    sets.precast.WS = {
        head="Meghanada Visor +2",
		neck="Fotia Gorget",
		ear1="Moonshade Earring",
		ear2="Telos Earring",
        body="Laksa. Frac +3",
		hands="Meg. Gloves +2",
		ring1="Regal Ring",
		ring2="Ifrit Ring +1",
        back=gear.str_wsd_jse_back,
		waist="Fotia Belt",
		legs="Meg. Chausses +2",
		feet="Lanun Bottes +3"
		}
		
    sets.precast.WS.Acc = {
        head="Carmine Mask +1",
		neck="Combatant's Torque",
		ear1="Digni. Earring",
		ear2="Telos Earring",
        body="Meg. Cuirie +2",
		hands="Meg. Gloves +2",
		ring1="Regal Ring",
		ring2="Ilabrat Ring",
        back=gear.str_wsd_jse_back,
		waist="Grunfeld Rope",
		legs="Carmine Cuisses +1",
		feet="Lanun Bottes +3"
		}		
		
    -- Specific weaponskill sets.  Uses the base set if an appropriate WSMod version isn't found.

    sets.precast.WS['Requiescat'] = set_combine(sets.precast.WS, {head="Carmine Mask +1",ring2="Rufescent Ring",legs="Carmine Cuisses +1",feet="Carmine Greaves +1"})
	
	sets.precast.WS['Savage Blade'] = {
		ammo=gear.WSbullet,
        head="Lilitu Headpiece",
        body="Laksa. Frac +3",
		hands="Meg. Gloves +2",		
		legs="Herculean Trousers",
		feet="Lanun Bottes +3",		
		neck="Fotia Gorget",
		waist="Prosilio Belt +1",
		ear1="Moonshade Earring",
--		ear2="Ishvara Earring",
--		ring1="Regal Ring",
--		ring2="Ifrit Ring +1",
        back=gear.str_wsd_jse_back,

		}

    sets.precast.WS['Savage Blade'].Acc = set_combine(sets.precast.WS['Savage Blade'],{
	    head="Meghanada Visor +2",
		legs="Meghanada Chausses +2",
		})
	
    sets.precast.WS['Last Stand'] = {
		ammo=gear.WSbullet,
        head="Lanun Tricorne +2",
		body="Laksa. Frac +3",
		hands="Meg. Gloves +2",
		legs="Meg. Chausses +2",
		feet="Lanun Bottes +3",
		neck="Fotia Gorget",
		waist="Fotia Belt",
		ear1="Moonshade Earring",
--		ear2="Ishvara Earring",
		ring1="Apate Ring",
		ring2="Dingir Ring",
        back=gear.ranger_wsd_jse_back
		
		}

    sets.precast.WS['Last Stand'].Acc = set_combine(sets.precast.WS['Last Stand'], {
		ammo=gear.WSbullet,
		neck="Iskur Gorget",
		ring1="Haverton Ring",
		ring2="Hajduk Ring +1"})
		
    sets.precast.WS['Detonator'] = sets.precast.WS['Last Stand']
    sets.precast.WS['Detonator'].Acc = sets.precast.WS['Last Stand'].Acc
    sets.precast.WS['Slug Shot'] = sets.precast.WS['Last Stand']
    sets.precast.WS['Slug Shot'].Acc = sets.precast.WS['Last Stand'].Acc
    sets.precast.WS['Numbing Shot'] = sets.precast.WS['Last Stand']
    sets.precast.WS['Numbing Shot'].Acc = sets.precast.WS['Last Stand'].Acc
    sets.precast.WS['Sniper Shot'] = sets.precast.WS['Last Stand']
    sets.precast.WS['Sniper Shot'].Acc = sets.precast.WS['Last Stand'].Acc
    sets.precast.WS['Split Shot'] = sets.precast.WS['Last Stand']
    sets.precast.WS['Split Shot'].Acc = sets.precast.WS['Last Stand'].Acc
	
    sets.precast.WS['Leaden Salute'] = {
		ammo=gear.MAbullet,
        head="Pixie Hairpin +1",
		neck="Sanctity Necklace",
		ear1="Moonshade Earring",
		ear2="Friomisi Earring",
        body="Lanun Frac +3",
		hands="Carmine Fin. Ga. +1",
		ring1="Dingir Ring",
		ring2="Archon Ring",
        back=gear.magic_wsd_jse_back,
		waist="Svelt. Gouriz +1",
		legs="Laksa. Trews +3",
		feet="Lanun Bottes +3"}

    sets.precast.WS['Leaden Salute'].Acc = set_combine(sets.precast.WS['Leaden Salute'], {
		neck="Sanctity Necklace",
		legs="Laksa. Trews +3",
		feet="Lanun Bottes +3"})

    sets.precast.WS['Wildfire'] = set_combine(sets.precast.WS['Leaden Salute'], {
        head=gear.herculean_nuke_head,
		ear1="Crematio Earring",
		ring1="Fenrir Ring +1"})

    sets.precast.WS['Wildfire'].Acc = {ammo=gear.MAbullet,
        head=gear.herculean_nuke_head,neck="Sanctity Necklace",ear1="Crematio Earring",ear2="Friomisi Earring",
        body="Laksa. Frac +3",hands="Leyline Gloves",ring1="Regal Ring",ring2="Dingir Ring",
        back=gear.magic_wsd_jse_back,waist="Eschan Stone",legs="Laksa. Trews +3",feet="Lanun Bottes +3"}
		
    sets.precast.WS['Hot Shot'] = sets.precast.WS['Wildfire']
    sets.precast.WS['Hot Shot'].Acc = sets.precast.WS['Wildfire'].Acc
		
	-- Swap to these on Moonshade using WS if at 3000 TP
	sets.MaxTP = {}
	sets.AccMaxTP = {}
        
    -- Midcast Sets
    sets.midcast.FastRecast = {
        head="Carmine Mask +1",neck="Baetyl Pendant",ear1="Enchntr. Earring +1",ear2="Loquacious Earring",
        body="Dread Jupon",hands="Leyline Gloves",ring1="Kishar Ring",ring2="Lebeche Ring",
        back="Moonlight Cape",waist="Flume Belt +1",legs="Rawhide Trousers",feet="Carmine Greaves +1"}
        
    -- Specific spells

	sets.midcast.Cure = {
        head="Carmine Mask +1",neck="Phalaina Locket",ear1="Enchntr. Earring +1",ear2="Mendi. Earring",
        body="Dread Jupon",hands="Leyline Gloves",ring1="Janniston Ring",ring2="Lebeche Ring",
        back="Solemnity Cape",waist="Flume Belt +1",legs="Carmine Cuisses +1",feet="Carmine Greaves +1"}
	
	sets.Self_Healing = {neck="Phalaina Locket",hands="Buremte Gloves",ring2="Kunaji Ring",waist="Gishdubar Sash"}
	sets.Cure_Received = {neck="Phalaina Locket",hands="Buremte Gloves",ring2="Kunaji Ring",waist="Gishdubar Sash"}
	sets.Self_Refresh = {waist="Gishdubar Sash"}
	
    sets.midcast.Utsusemi = sets.midcast.FastRecast

    -- Ranged gear
    sets.midcast.RA = {
		ammo=gear.RAbullet,
        head="Meghanada Visor +2",
		body="Oshosi Vest +1",
		hands="Carmine Fin. Ga. +1",
		legs="Adhemar Kecks +1",
		feet="Adhemar Gamashes +1",
		neck="Iskur Gorget",
		ear1="Clearview Earring",	--ear1="Telos Earring",
		ear2="Enervating Earring",
		ring1="Dingir Ring",
		ring2="Ilabrat Ring",
        back=gear.tp_range_jse_back,
		waist="K. Kachina Belt +1"
		}

    sets.midcast.RA.Acc = set_combine(sets.midcast.RA, {
		head="Laksa. Tricorne +3",	
        body="Laksa. Frac +3",
		hands="Meg. Gloves +2",
		legs="Laksa. Trews +3",
		feet="Meg. Jam. +2",
		neck="Iskur Gorget",		
		ring1="Hajduk Ring +1",
		ring2="Haverton Ring"		--ring2"Regal Ring"
		})
		
	sets.buff['Triple Shot'] = {body="Chasseur's Frac +1"}
    
    -- Sets to return to when not performing an action.
	
	sets.DayIdle = {}
	sets.NightIdle = {}
	
	sets.buff.Doom = set_combine(sets.buff.Doom, {})
    
    -- Resting sets
    sets.resting = {}
    

    -- Idle sets
    sets.idle = {ammo=gear.RAbullet,
        head="Meghanada Visor +2",neck="Loricate Torque +1",ear1="Genmei Earring",ear2="Sanare Earring",
        body="Meg. Cuirie +2",hands=gear.herculean_dt_hands,ring1="Defending Ring",ring2="Dark Ring",
        back="Moonlight Cape",waist="Flume Belt +1",legs="Carmine Cuisses +1",feet=gear.herculean_dt_feet}
		
    sets.idle.Refresh = {ammo=gear.RAbullet,
        head="Rawhide Mask",neck="Loricate Torque +1",ear1="Genmei Earring",ear2="Ethereal Earring",
        body="Mekosu. Harness",hands=gear.herculean_refresh_hands,ring1="Defending Ring",ring2="Dark Ring",
        back="Moonlight Cape",waist="Flume Belt +1",legs="Rawhide Trousers",feet=gear.herculean_dt_feet}
    
    -- Defense sets
    sets.defense.PDT = {
		ammo=gear.RAbullet,
        head="Meghanada Visor +2",
		neck="Loricate Torque +1",
		ear1="Genmei Earring",
		ear2="Sanare Earring",
        body="Meg. Cuirie +2",
		hands=gear.herculean_dt_hands,
		ring1="Defending Ring",
		ring2="Dark Ring",
        back="Moonlight Cape",
		waist="Flume Belt +1",
		legs="Meg. Chausses +2",
		feet=gear.herculean_dt_feet
		}

    sets.defense.MDT = {ammo=gear.RAbullet,
        head="Meghanada Visor +2",neck="Loricate Torque +1",ear1="Etiolation Earring",ear2="Sanare Earring",
        body="Meg. Cuirie +2",hands=gear.herculean_dt_hands,ring1="Defending Ring",ring2="Dark Ring",
        back="Moonlight Cape",waist="Flume Belt +1",legs="Meg. Chausses +2",feet="Ahosi Leggings"}
		
    sets.defense.MEVA = {ammo=gear.RAbullet,
        head="Meghanada Visor +2",neck="Loricate Torque +1",ear1="Etiolation Earring",ear2="Sanare Earring",
        body="Meg. Cuirie +2",hands=gear.herculean_dt_hands,ring1="Defending Ring",ring2="Dark Ring",
        back="Moonlight Cape",waist="Flume Belt +1",legs="Meg. Chausses +2",feet="Ahosi Leggings"}

    sets.Kiting = {legs="Carmine Cuisses +1"}
	sets.TreasureHunter = set_combine(sets.TreasureHunter, {})
	sets.DWMax = {ear1="Dudgeon Earring",ear2="Heartseeker Earring",body="Adhemar Jacket +1",hands="Floral Gauntlets",waist="Reiki Yotai"}

	-- Weapons sets
	--sets.weapons.Default = {main="Hepatizon Rapier +1",sub="Odium",range="Death Penalty"}
	sets.weapons.LeadenWeapons = {main="Hepatizon Rapier +1",sub="Atoyac",range="Death Penalty"}
	sets.weapons.SavageWeapons = {main="Hep. Sapara +1",sub="Demersal Degen +1",range="Anarchy +2"}	
	sets.weapons.LastStandWeapons = {main="Kustawi +1",sub="Nusku Shield",range="Fomalhaut"}
	sets.weapons.DualRangedWeapons = {main="Hepatizon Rapier +1",sub="Kustawi +1",range="Fomalhaut"}
	sets.weapons.RollMeleeWeapons = {main="Hep. Sapara +1",sub="Blurred Knife +1",range="Compensator"}
	sets.weapons.RollRangedWeapons = {main="Fettering Blade",sub="Kustawi +1",range="Compensator"}



	
    -- Engaged sets

    -- Variations for TP weapon and (optional) offense/defense modes.  Code will fall back on previous
    -- sets if more refined versions aren't defined.
    -- If you create a set with both offense and defense modes, the offense mode should be first.
    -- EG: sets.engaged.Dagger.Accuracy.Evasion
    
    -- Normal melee group
    sets.engaged = {		--Acc
		head="Adhemar Bonnet +1",		-- 20
		body="Adhemar Jacket +1",		-- 55
		hands="Adhemar Wrist. +1",		-- 52
		legs="Samnuha Tights",			-- 15
--		feet=gear.herculean_ta_feet,		-- 
		
		neck="Iskur Gorget",			-- 0
		waist="Windbuffet Belt +1",		-- 2
		ear1="Cessance Earring",		-- 6
		ear2="Brutal Earring",			-- 0
		ring1="Epona's Ring",			-- 0
		ring2="Petrov Ring",			-- 0
		back=gear.tp_dbl_jse_back		-- 30
		}
    
    sets.engaged.Acc = set_combine(sets.engaged,{
		head="Carmine Mask +1",
--		neck="Combatant's Torque",
		ear1="Cessance Earring",
--		ear2="Telos Earring",
		body="Meg. Cuirie +2",
		hands="Adhemar Wrist. +1",
--		ring1="Epona's Ring",
		ring2="Petrov Ring",
		back=gear.tp_dbl_jse_back,
		waist="Olseni Belt",
		legs="Carmine Cuisses +1",
		feet=gear.herculean_acc_feet
		})

    sets.engaged.DW = {
		head="Adhemar Bonnet +1",
		neck="Iskur Gorget",
		ear1="Suppanomimi",
		ear2="Brutal Earring",
		body="Adhemar Jacket +1",
		hands="Adhemar Wrist. +1",
		ring1="Ilabrat Ring",
		ring2="Petrov Ring",
		back=gear.tp_dbl_jse_back,
		waist="Windbuffet Belt +1",
		legs="Samnuha Tights",
		feet="Adhemar Gamashes +1"}
    
    sets.engaged.DW.Acc = {
		head="Carmine Mask +1",
		neck="Combatant's Torque",
		ear1="Digni. Earring",
		ear2="Telos Earring",
		body="Meg. Cuirie +2",
		hands="Floral Gauntlets",
		ring1="Ramuh Ring +1",
		ring2="Ramuh Ring +1",
		back=gear.tp_dbl_jse_back,
		waist="Olseni Belt",
		legs="Carmine Cuisses +1",
		feet=gear.herculean_acc_feet}

end

-- Select default macro book on initial load or subjob change.
function select_default_macro_book()
    if player.sub_job == 'NIN' then
        set_macro_page(2, 16)
    elseif player.sub_job == 'DNC' then
		set_macro_page(2, 16)
    elseif player.sub_job == 'RNG' then
        set_macro_page(2, 16)
    else
        set_macro_page(2, 16)
    end   


end